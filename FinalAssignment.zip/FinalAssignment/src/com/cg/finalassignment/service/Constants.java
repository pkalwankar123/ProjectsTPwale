package com.cg.finalassignment.service;

public class Constants {

	public static final String ENTIDAD_ERR = "ENTIDAD is alphanumeric field and should contain specific characters";
	public static final String PROCESO_DE_NOMINA_ERR = "PROCESO_DE_NOMINA is alphanumeric field and should contain specific characters";
	public static final String NOMBRE_ERR = "NOMBRE is alphabetical field";
	public static final String PRIMER_APELLIDO_ERR = "PRIMER_APELLIDO is alphabetical field";
	public static final String SEGUNDO_APELLIDO_ERR = "SEGUNDO_APELLIDO is alphabetical field";
	public static final String CURP_ERR = "CURP is alphanumeric field";
	public static final String RFC_ERR = "RFC is alphanumeric field";
	public static final String CLC_ERR = "CLC is numeric field";
	public static final String CVE_CONCEPTO_ERR = "CVE_CONCEPTO is numeric field";
	public static final String DESCRIPCION_ERR = "DESCRIPCION is alphanumeric field";
	public static final String SUMADEIMPORTE_ERR = "SUMADEIMPORTE is numeric field";
	
	
	public static final String CPTO_ERR = "CPTO is alphanumeric field";
	public static final String NUMPEN_ERR = "NUMPEN is numeric field";
	public static final String SEXO_ERR = "SEXO is alphabetic field";
	public static final String RAMO_ERR = "RAMO is numeric field";
	public static final String ID_ERR = "ID is alphanumeric field";
	
	public static final String OUTPUT = " - Output.txt";
	public static final String ERROR = "Error.csv";
	
}
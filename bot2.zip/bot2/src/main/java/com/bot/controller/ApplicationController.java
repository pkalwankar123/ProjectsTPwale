package com.bot.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/chatbot")
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST})
public class ApplicationController {

	@Autowired
	private Chatbot chatBot;
	
	@GetMapping("/ping")
	public String getPing(@RequestParam("ping") String ping) {
		System.out.println(ping);
		return ping;
		
	}
	
	@SuppressWarnings({ "static-access", "rawtypes" })
	@GetMapping("/botResponse")
	public ResponseEntity getBotApp(@RequestParam("query") String query) {
		
		String response =  chatBot.getBot(query);
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
	
	
}



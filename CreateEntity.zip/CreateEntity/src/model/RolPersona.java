package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ROL_PERSONAS database table.
 * 
 */
@Entity
@Table(name="ROL_PERSONAS")
@NamedQuery(name="RolPersona.findAll", query="SELECT r FROM RolPersona r")
public class RolPersona implements Serializable {
	private static final long serialVersionUID = 1L;

	private String cdgarant;

	@Temporal(TemporalType.DATE)
	@Column(name="FECH_STATUS")
	private Date fechStatus;

	@Column(name="ID_PERSONA")
	private BigDecimal idPersona;

	private BigDecimal nmpoliza;

	private BigDecimal numservicio;

	@Column(name="SEQ_BENF")
	private BigDecimal seqBenf;

	@Column(name="SEQ_PERSONA")
	private BigDecimal seqPersona;

	private String status;

	@Column(name="TIPO_PERSONA")
	private String tipoPersona;

	public RolPersona() {
	}

	public String getCdgarant() {
		return this.cdgarant;
	}

	public void setCdgarant(String cdgarant) {
		this.cdgarant = cdgarant;
	}

	public Date getFechStatus() {
		return this.fechStatus;
	}

	public void setFechStatus(Date fechStatus) {
		this.fechStatus = fechStatus;
	}

	public BigDecimal getIdPersona() {
		return this.idPersona;
	}

	public void setIdPersona(BigDecimal idPersona) {
		this.idPersona = idPersona;
	}

	public BigDecimal getNmpoliza() {
		return this.nmpoliza;
	}

	public void setNmpoliza(BigDecimal nmpoliza) {
		this.nmpoliza = nmpoliza;
	}

	public BigDecimal getNumservicio() {
		return this.numservicio;
	}

	public void setNumservicio(BigDecimal numservicio) {
		this.numservicio = numservicio;
	}

	public BigDecimal getSeqBenf() {
		return this.seqBenf;
	}

	public void setSeqBenf(BigDecimal seqBenf) {
		this.seqBenf = seqBenf;
	}

	public BigDecimal getSeqPersona() {
		return this.seqPersona;
	}

	public void setSeqPersona(BigDecimal seqPersona) {
		this.seqPersona = seqPersona;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTipoPersona() {
		return this.tipoPersona;
	}

	public void setTipoPersona(String tipoPersona) {
		this.tipoPersona = tipoPersona;
	}

}
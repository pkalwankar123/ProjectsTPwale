package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DES_AGENTES database table.
 * 
 */
@Embeddable
public class DesAgentePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String id;

	@Column(name="COD_PRODUCTO")
	private String codProducto;

	private String nmsolici;

	@Column(name="TIPO_AGENTE")
	private String tipoAgente;

	private long agente;

	public DesAgentePK() {
	}
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCodProducto() {
		return this.codProducto;
	}
	public void setCodProducto(String codProducto) {
		this.codProducto = codProducto;
	}
	public String getNmsolici() {
		return this.nmsolici;
	}
	public void setNmsolici(String nmsolici) {
		this.nmsolici = nmsolici;
	}
	public String getTipoAgente() {
		return this.tipoAgente;
	}
	public void setTipoAgente(String tipoAgente) {
		this.tipoAgente = tipoAgente;
	}
	public long getAgente() {
		return this.agente;
	}
	public void setAgente(long agente) {
		this.agente = agente;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DesAgentePK)) {
			return false;
		}
		DesAgentePK castOther = (DesAgentePK)other;
		return 
			this.id.equals(castOther.id)
			&& this.codProducto.equals(castOther.codProducto)
			&& this.nmsolici.equals(castOther.nmsolici)
			&& this.tipoAgente.equals(castOther.tipoAgente)
			&& (this.agente == castOther.agente);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.id.hashCode();
		hash = hash * prime + this.codProducto.hashCode();
		hash = hash * prime + this.nmsolici.hashCode();
		hash = hash * prime + this.tipoAgente.hashCode();
		hash = hash * prime + ((int) (this.agente ^ (this.agente >>> 32)));
		
		return hash;
	}
}
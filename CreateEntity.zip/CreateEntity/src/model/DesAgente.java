package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the DES_AGENTES database table.
 * 
 */
@Entity
@Table(name="DES_AGENTES")
@NamedQuery(name="DesAgente.findAll", query="SELECT d FROM DesAgente d")
public class DesAgente implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DesAgentePK id;

	private BigDecimal porcentaje;

	public DesAgente() {
	}

	public DesAgentePK getId() {
		return this.id;
	}

	public void setId(DesAgentePK id) {
		this.id = id;
	}

	public BigDecimal getPorcentaje() {
		return this.porcentaje;
	}

	public void setPorcentaje(BigDecimal porcentaje) {
		this.porcentaje = porcentaje;
	}

}
package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the UP_PERSONAS database table.
 * 
 */
@Entity
@Table(name="UP_PERSONAS")
@NamedQuery(name="UpPersona.findAll", query="SELECT u FROM UpPersona u")
public class UpPersona implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="APELLIDO_1")
	private String apellido1;

	@Column(name="APELLIDO_2")
	private String apellido2;

	private String curp;

	@Temporal(TemporalType.DATE)
	@Column(name="FECHA_NAC")
	private Date fechaNac;

	private String gender;

	@Column(name="IDENTIFIER_1")
	private String identifier1;

	@Column(name="IDENTIFIER_2")
	private String identifier2;

	@Column(name="IDENTIFIER_3")
	private String identifier3;

	private String nombre;

	private String rfc;

	@Column(name="SEQ_PERSONA")
	private BigDecimal seqPersona;

	public UpPersona() {
	}

	public String getApellido1() {
		return this.apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return this.apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public String getCurp() {
		return this.curp;
	}

	public void setCurp(String curp) {
		this.curp = curp;
	}

	public Date getFechaNac() {
		return this.fechaNac;
	}

	public void setFechaNac(Date fechaNac) {
		this.fechaNac = fechaNac;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIdentifier1() {
		return this.identifier1;
	}

	public void setIdentifier1(String identifier1) {
		this.identifier1 = identifier1;
	}

	public String getIdentifier2() {
		return this.identifier2;
	}

	public void setIdentifier2(String identifier2) {
		this.identifier2 = identifier2;
	}

	public String getIdentifier3() {
		return this.identifier3;
	}

	public void setIdentifier3(String identifier3) {
		this.identifier3 = identifier3;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRfc() {
		return this.rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public BigDecimal getSeqPersona() {
		return this.seqPersona;
	}

	public void setSeqPersona(BigDecimal seqPersona) {
		this.seqPersona = seqPersona;
	}

}
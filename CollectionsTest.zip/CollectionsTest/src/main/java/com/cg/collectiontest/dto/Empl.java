package com.cg.collectiontest.dto;

import java.util.Comparator;
import java.util.LinkedList;

public class Empl implements Comparator<Empl>{
private String name;
private double sal;

public Empl() {
}

public Empl(String name, double sal) {
	super();
	this.name = name;
	this.sal = sal;
}


public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getSal() {
	return sal;
}

public void setSal(double sal) {
	this.sal = sal;
}

@Override
public String toString() {
	return "Empl [name=" + name + ", sal=" + sal + "]";
}

public int compare(Empl o1, Empl o2) {
	// TODO Auto-generated method stub
	
	if(o1.getSal() < o2.getSal()) {
		return -1;
	}
	else if(o1.getSal() > o2.getSal()){
		return 1;
	}
	else {
	
	
	return 0;
	}
}



}


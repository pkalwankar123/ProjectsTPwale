package com.cg.collectiontest.dto;

public class Emplo implements Comparable<Emplo>{
	
	private String name;
	private double sal;

	public Emplo() {
	}

	public Emplo(String name, double sal) {
		super();
		this.name = name;
		this.sal = sal;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "Emplo [name=" + name + ", sal=" + sal + "]";
	}

	public int compareTo(Emplo o1) {
		// TODO Auto-generated method stub
	
		//return this.getName().compareToIgnoreCase(o1.getName());
		
		
		if(this.getSal() < o1.getSal()) {
			return 1;
		}
		else if(this.getSal() > o1.getSal()){
			return -1;
		}
		else {
		
		
		return 0;
		}
	}

	}

	




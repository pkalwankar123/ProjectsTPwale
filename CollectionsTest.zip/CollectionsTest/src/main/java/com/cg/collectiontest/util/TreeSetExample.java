package com.cg.collectiontest.util;

import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

import com.cg.collectiontest.dto.Emplo;

public class TreeSetExample {
    public static void main(String args[]) {
        // TreeSet of String Type
        TreeSet<String> tset = new TreeSet<String>();

        // Adding elements to TreeSet<String>
        tset.add("ABC");
        tset.add("String");
        tset.add("Test");
        tset.add("Pen");
        tset.add("Ink");
        tset.add("Jack");

        //Displaying TreeSet
        System.out.println(tset);

        // TreeSet of Integer Type
        TreeSet<Integer> tset2 = new TreeSet<Integer>();

        // Adding elements to TreeSet<Integer>
        tset2.add(88);
        tset2.add(7);
        tset2.add(101);
        tset2.add(0);
        tset2.add(1);
        tset2.add(3);
        tset2.add(222);
        System.out.println(tset2);

        int a=tset2.ceiling(2);
        System.out.println(a);
        
        
        
        System.out.println(tset2.comparator());
        Iterator itr=tset2.descendingIterator();
        
        while(itr.hasNext()) {
        	Integer it=(Integer)itr.next();
        	System.out.println(it);
        }
        
        
        System.out.println(tset2.first());
        
        System.out.println(tset2.descendingSet());
        
        System.out.println(tset2.floor(2));
        
        System.out.println(tset2.last());
        
        System.out.println(tset2.pollFirst());
        
        System.out.println(tset2.pollLast());
        
        System.out.println(tset2.headSet(101));
    
        System.out.println(tset2.headSet(101, true));
        
        System.out.println(tset2.subSet(1, 101));
       
        System.out.println(tset2.subSet(1, false, 101, true));
        
        System.out.println(tset2.tailSet(88));
        
        System.out.println(tset2.isEmpty());
        
        TreeSet<Emplo> tset3 = new TreeSet<Emplo>();
    tset3.add(new Emplo("Pradip",120));
    tset3.add(new Emplo("pradip",20));
    tset3.add(new Emplo("Vjiay",23));
    tset3.add(new Emplo("Danish",15));
    tset3.add(new Emplo("AD",17));
    tset3.add(new Emplo("zen",15));
    
    for(Emplo e:tset3) {
    	System.out.println(e);
    }
    
    }
}

package com.cg.collectiontest.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.cg.collectiontest.dto.Emplo;

public class MyApplication {

	public static void main(String[] args) {
	/*
	 * Java collections: List Interface:-
	 * 							1. ArrayList
	 * 							2. LinkedList
	 * 							3. Vectors	
	 */		

		ArrayList al1=new ArrayList();    //1st ArrayList
		al1.add("A");    //Add method(Object)
		al1.add("B");
		al1.add("C");		
		System.out.println(al1);
		
		ArrayList al2=new ArrayList();    //2nd ArrayList
		al2.add("x");    //Add method(Object)
		al2.add("y");
		al2.add("z");
		al2.add("zz");
			
		al1.add(2, "z");  //Add method(index,object) at the specific position
		System.out.println(al1);
		
		al1.remove(2);    //Remove method(specified index)
		System.out.println(al1);
		
		al1.addAll(al2);     //Add All elements from 2nd Arraylist to 1st Arraylist
		System.out.println(al1);
		
		al1.addAll(2, al2);		//Add All elements 
		System.out.println(al1);		
		System.out.println(al2);
		
		al1=(ArrayList)al2.clone();   //Add All elements of al2 object clonning to al1
		System.out.println(al2);
		System.out.println(al1);
		
		Boolean a=al2.contains("A");      //it returns the boolean result
		System.out.println(a);
		
		System.out.println(al1.containsAll(al2));       //it returns the boolean result from the list
		
		System.out.println(al1.size());					////it returns the ArrayList size
	
		System.out.println(al1.subList(2, 4));					//it returns the sublist from one index to another one

		System.out.println(al1.removeAll(al1.subList(2, 4)));			//it removes the sublist from one index to another one that is the sublist
		
		System.out.println(al1.equals(al2));					//returns boolean value to check that one object with another one 
		
		
		
		for(int i=0; i < al1.size(); i++) {
			 
			System.out.println(al1.get(i));
		}
			    /*
			 
			To get a comparator that imposes reverse order on a Collection's elements 
			 
			we can use static Comparator reverseOrder() operation of Collections class
			    */
			    Comparator comparator = Collections.reverseOrder();
			  
			    // Collection.sort(List list, Comparator c) static operation sorts ArrayList elements using a Comparator
			    Collections.sort(al1,comparator);
			 
			    System.out.println("Elements in ArrayList after sorting :");
			    for(int i=0; i < al1.size(); i++)
			 
			System.out.println(al1.get(i));
			  
		al1.clear();									//removing all the values from the Arraylist
		System.out.println(al1);
		System.out.println(al1.isEmpty());				//returns boolean value to check whether it is empty or not
		
		
		ArrayList<Emplo> listii=new ArrayList<Emplo>();
		listii.add(new Emplo("Pradip",10000));
		listii.add(new Emplo("Shivaji",200000));
		listii.add(new Emplo("Laxmibai",3000));
		listii.add(new Emplo("kalwankar",400000));
		
		Collections.sort(listii);
		
		for(Emplo emp:listii) {
			System.out.println(emp.toString());
		}
	}

}

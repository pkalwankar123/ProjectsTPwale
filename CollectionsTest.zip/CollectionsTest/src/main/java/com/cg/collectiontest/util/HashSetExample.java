package com.cg.collectiontest.util;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;

public class HashSetExample {
	   public static void main(String args[]) {
	      // HashSet declaration
	      HashSet<String> hset = 
	               new HashSet<String>();

	      // Adding elements to the HashSet
	      hset.add("Apple");
	      hset.add("Mango");
	      hset.add("Grapes");
	      hset.add("Orange");
	      hset.add("Fig");
	      //Addition of duplicate elements
	      hset.add("Apple");
	      hset.add("Mango");
	      //Addition of null values
	      hset.add(null);
	      hset.add(null);

	      //Displaying HashSet elements
	      System.out.println(hset);
	      
	      HashSet<String> hset2 = 
	               new HashSet<String>();

	      // Adding elements to the HashSet
	      hset2.add("A");
	      hset2.add("M");
	      hset2.add("G");
	      hset2.add("O");
	      hset2.add("F");
	      
	      
	     boolean b= hset.contains("pradip");
	      System.out.println(b);
	      
	      boolean b1=hset.containsAll(hset2);
	      System.out.println(b1);
	      
	     System.out.println(hset.hashCode());
	     System.out.println(hset2.hashCode());
	      
	      System.out.println(hset.equals(hset2));
	      
	      hset.addAll(hset2);
	      System.out.println(hset);
	      
	      hset.removeAll(hset2);
	      System.out.println(hset);
	      
	     // hset.retainAll(hset2);
	      //System.out.println(hset);
	      
	      System.out.println(hset.getClass());
	      
	      Iterator ite=hset.iterator(); 
	      
	      while(ite.hasNext()) {
	    	  String setw=(String)ite.next();
	    	  System.out.println(setw);
	      }
	      
	    }
	}

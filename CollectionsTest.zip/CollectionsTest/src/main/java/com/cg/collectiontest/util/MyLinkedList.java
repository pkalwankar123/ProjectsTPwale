package com.cg.collectiontest.util;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.cg.collectiontest.dto.Empl;

public class MyLinkedList {

	public static void main(String[] args) {
		
		LinkedList list=new LinkedList();
		
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		System.out.println(list);
		
LinkedList<String> listGen=new LinkedList<String>();
		
		listGen.add("pp");
		listGen.add("x");
		listGen.add("y");
		listGen.add("z");
		System.out.println(listGen);
	
		list.add(3, "z");
		System.out.println(list);
		
		list.addFirst("pradip");
		System.out.println(list);
		
		list.addLast("kalwankar");
		System.out.println(list);
		
		list.addAll(listGen);
		System.out.println(list);
				
		list.addAll(2, listGen);
		System.out.println(list);
		
		Boolean a=list.contains("pp");
		System.out.println(a);
		
		Boolean a1=list.containsAll(listGen);
		System.out.println(a);
		
		listGen=(LinkedList)list.clone();
		System.out.println(listGen);
			
		System.out.println(list.hashCode());
		System.out.println(listGen.hashCode());
		
		list.clear();									//removing all the values from the Arraylist
		System.out.println(list);
		System.out.println(list.isEmpty());	

	
		 LinkedList<Empl> listii = new LinkedList<Empl>();
		 listii.add(new Empl("Ram",7000));
		 listii.add(new Empl("John",6000));
		 listii.add(new Empl("Crish",2000));
		 listii.add(new Empl("Tom",2400));
	        Collections.sort(listii, new Empl());;
	        System.out.println("Sorted list entries: ");
	        for(Empl e:listii){
	            System.out.println(e);
	        }
	
	}

}

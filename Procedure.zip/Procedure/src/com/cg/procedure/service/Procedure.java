package com.cg.procedure.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

public class Procedure {
	  public static void main(String[] args) throws Exception {
	    Connection conn = getOracleConnection();
	    
	    String proc3StoredProcedure = "{ call P_EMISION(?, ?, ?) }";
	    
	    CallableStatement cs = conn.prepareCall(proc3StoredProcedure);
	    cs.setString(1, "abcd");
	    cs.setInt(3, 10);
	    cs.registerOutParameter(2, java.sql.Types.VARCHAR);
	    cs.registerOutParameter(3, java.sql.Types.INTEGER);
	    cs.execute();
	    String param2 = cs.getString(2);
	    int param3 = cs.getInt(3);
	    System.out.println("param2=" + param2);
	    System.out.println("param3=" + param3);
	    conn.close();
	  }

	/*  private static Connection getHSQLConnection() throws Exception {
	    Class.forName("org.hsqldb.jdbcDriver");
	    System.out.println("Driver Loaded.");
	    String url = "jdbc:hsqldb:data/tutorial";
	    return DriverManager.getConnection(url, "sa", "");
	  }

	  public static Connection getMySqlConnection() throws Exception {
	    String driver = "org.gjt.mm.mysql.Driver";
	    String url = "jdbc:mysql://localhost/demo2s";
	    String username = "oost";
	    String password = "oost";

	    Class.forName(driver);
	    Connection conn = DriverManager.getConnection(url, username, password);
	    return conn;
	  }*/

	  public static Connection getOracleConnection() throws Exception {
	    String driver = "oracle.jdbc.driver.OracleDriver";
	    String url = "jdbc:oracle:thin:@10.207.180.29:1521:ORCL11";
	    String username = "seus";
	    String password = "seus";

	    Class.forName(driver); // load Oracle driver
	    Connection conn = DriverManager.getConnection(url, username, password);
	    return conn;
	  }
	}

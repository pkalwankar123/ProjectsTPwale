package com.capgemini.demo;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class JDBCConnect {

	public static void main(String[] args) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return;
		}

		Connection connection = null;
		Statement selectStatement= null;
		Statement updateStatement=null;
		Statement insertStatement=null;
		PreparedStatement preparedStatement=null;
		CallableStatement prcCall=null;
		CallableStatement funCall=null;
		try {
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.207.180.29:1521:ORCL11", "seus", "seus");
			connection.setAutoCommit(false);
			System.out.println("SQL Connection to database established!");

			selectStatement=connection.createStatement();
			ResultSet result=selectStatement.executeQuery("select * from test_team");
			while(result.next()) {
				System.out.println(String.join("->", 
						result.getString(1), 
						result.getString(2),
						result.getString(3),
						result.getString(4),
						result.getString(5),
						result.getString(6)));
			}
			
			/*updateStatement=connection.createStatement();
			int recordsUpdated=updateStatement.executeUpdate("update test_team set name='RAJ' where name='TEST'");
			System.out.println("Records Updated:"+recordsUpdated);*/
			
			/*insertStatement=connection.createStatement();
			int insertcount=insertStatement.executeUpdate("INSERT INTO TEST_TEAM VALUES(1,'AMIT','JAVA',90000,8,4)");
			System.out.println("Insert Count:"+insertcount);*/
			
			
			/*preparedStatement=connection.prepareStatement("update test_team set name=? where name=?");
			preparedStatement.setString(1, "TEST");
			preparedStatement.setString(2, "RAJ");
			int recordsUpdated=preparedStatement.executeUpdate();
			System.out.println("Records Updated:"+recordsUpdated);*/
			
			/*prcCall=connection.prepareCall("{ call PRC_GET_PROJECT_NAME(?,?) }");
			prcCall.setString(1,"RAHUL");
			prcCall.registerOutParameter(2, Types.VARCHAR);
			prcCall.executeQuery();
			String projectName=prcCall.getString(2);
			System.out.println("PRC:"+projectName);*/
			
			
			/*funCall=connection.prepareCall("{ ?= call FNC_GET_PROJECT_NAME(?)}");
			funCall.setString(2,"RAHUL");
			funCall.registerOutParameter(1, Types.VARCHAR);
			funCall.executeQuery();
			projectName=prcCall.getString(2);
			System.out.println("FUN:"+projectName);*/
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return;
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (selectStatement != null) {
					selectStatement.close();
				}
				if (updateStatement != null) {
					updateStatement.close();
				}
				if (insertStatement != null) {
					insertStatement.close();
				}
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(prcCall!=null) {
					prcCall.close();
				}
				
				if(funCall!=null) {
					funCall.close();
				}
				
				System.out.println("Connection Closed!");

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}

package com.capgemini.dao;

import com.capgemini.model.TestTeam;

public interface TestTeamDao {

	TestTeam getById(Long id);

}

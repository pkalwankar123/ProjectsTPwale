package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.TestTeam;
import com.capgemini.service.TestTeamService;

@RestController
public class Controller {
	@Autowired
	TestTeamService testTeamService;
	
    @GetMapping(value = "/team/{id}")
    public @ResponseBody TestTeam getTestData(@PathVariable Long id) {
       
        return testTeamService.getById(id);
    }
}
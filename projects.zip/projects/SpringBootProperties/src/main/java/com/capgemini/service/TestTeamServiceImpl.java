package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.TestTeamDao;
import com.capgemini.model.TestTeam;
@Service
public class TestTeamServiceImpl implements TestTeamService {
	
	@Autowired
	TestTeamDao testTeamDao;

	@Override
	public TestTeam getById(Long id) {
		return testTeamDao.getById(id);
	}

}

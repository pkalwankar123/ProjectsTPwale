package com.capgemini.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capgemini.model.TestTeam;

@Repository
public class TestTeamDaoImpl implements TestTeamDao {

	@Autowired
	EntityManager entityManager;

	@Override
	public TestTeam getById(Long id) {
		return entityManager.find(TestTeam.class, id);
	}
}

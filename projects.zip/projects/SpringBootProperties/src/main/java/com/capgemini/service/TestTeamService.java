package com.capgemini.service;

import com.capgemini.model.TestTeam;

public interface TestTeamService {

	TestTeam getById(Long id);

}

package com.capgemini.config;

import java.util.Properties;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jndi.JndiTemplate;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class Config {
	

	static {
		SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
		DataSource ds = dataSource1();
		builder.bind( "JNDI_TEST_TEAM" , ds );
		try {
			builder.activate();
			System.out.println("JNDI_TEST_TEAM Activated");
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Bean
	   public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws NamingException {
	      LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
	      em.setDataSource(dataSource());
	      em.setPackagesToScan(new String[] { "com.capgemini.model" });
	      JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	      em.setJpaVendorAdapter(vendorAdapter);
	      em.setJpaProperties(additionalProperties());
	      return em;
	   }
	
	
	
	@Bean
	public static DataSource dataSource1(){
	    DriverManagerDataSource dataSource = new DriverManagerDataSource();
	    dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
	    dataSource.setUrl("jdbc:oracle:thin:@10.207.180.29:1521:ORCL11");
	    dataSource.setUsername( "seus" );
	    dataSource.setPassword( "seus" );
	    return dataSource;
	}	
	
	
	
	@Bean
	public DataSource dataSource() throws NamingException{
		DataSource dataSource= (DataSource) new JndiTemplate().lookup("JNDI_TEST_TEAM");
		System.out.println("JNDI_TEST_TEAM Found");
		return dataSource;
	}	
	
	/*@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
	    JpaTransactionManager transactionManager = new JpaTransactionManager();
	    transactionManager.setEntityManagerFactory(emf);
	    return transactionManager;
	}*/
	 
/*	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation(){
	    return new PersistenceExceptionTranslationPostProcessor();
	}
	 */
	Properties additionalProperties() {
	    Properties properties = new Properties();
	    properties.setProperty("hibernate.hbm2ddl.auto", "validate");
	    properties.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
	    properties.put("hibernate.show_sql", "true");
	    properties.put("hibernate.default_schema", "seus");
	    properties.put("hibernate.proc.param_null_passing", "true");
	    return properties;
	}
	
}

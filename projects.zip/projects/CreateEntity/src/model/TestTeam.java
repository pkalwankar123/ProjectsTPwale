package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TEST_TEAM database table.
 * 
 */
@Entity
@Table(name="TEST_TEAM")
@NamedQuery(name="TestTeam.findAll", query="SELECT t FROM TestTeam t")
public class TestTeam implements Serializable {
	private static final long serialVersionUID = 1L;

	public TestTeam() {
	}

}
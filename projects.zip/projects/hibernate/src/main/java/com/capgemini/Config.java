package com.capgemini;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Config {

    private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory() {
		
		//new Configuration() - allows the application to specify properties
		//configure() API method use the mappings and properties specified in an application resource named hibernate.cfg.xml
		//buildSessionFactory() instantiate a new SessionFactory
		sessionFactory= new Configuration().configure().buildSessionFactory();
		return sessionFactory;
	}
}


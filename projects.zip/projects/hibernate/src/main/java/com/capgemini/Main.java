package com.capgemini;

import java.sql.PreparedStatement;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Main {

	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		EntityManager entityManager = null;
		try {
			sessionFactory = Config.getSessionFactory();
			session = sessionFactory.openSession();
			List<TestTeam> testTeams = session.createQuery("from TestTeam", TestTeam.class).list();
			for (TestTeam testTeam : testTeams) {
				System.out.println(testTeam);
			}

			session.beginTransaction();
			TestTeam testTeam1= new TestTeam(20L, 12345L, "TEST", "TESTING", 5L, 5L);
			session.save(testTeam1);
			session.getTransaction().commit();
			
			entityManager = session.getEntityManagerFactory().createEntityManager();
			TestTeam testTeam = entityManager.find(TestTeam.class, 20L);
			System.out.println(testTeam);
			
			/*session.beginTransaction();
			TestTeam testTeam2=session.get(TestTeam.class, 20L);
			System.out.println(testTeam2);
			testTeam2.setName("CHANGED12");
			session.getTransaction().commit();	*/		
			
			
			session.beginTransaction();
			TestTeam testTeam2=session.get(TestTeam.class, 20L);
			//session.remove(testTeam2);
			session.remove(testTeam2);
			session.getTransaction().commit();	
			PreparedStatement
			
			entityManager.close();
			session.close();
			sessionFactory.close();

		} catch (Exception e) {
			e.printStackTrace();
			if(entityManager!=null)
			entityManager.close();
			if(session!=null)
			session.close();
			if(sessionFactory!=null)
			sessionFactory.close();

		}

	}

}

package com.capgemini.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class TestTeamMapper implements RowMapper<TestTeam> {

	public TestTeam mapRow(ResultSet resultSet, int i) throws SQLException {
		TestTeam person = new TestTeam();
		person.setId(resultSet.getLong("id"));
		person.setName(resultSet.getString("name"));
		person.setSpecification(resultSet.getString("specification"));
		person.setExperience(resultSet.getLong("experience"));
		person.setSalary(resultSet.getLong("salary"));
		person.setProjectId(resultSet.getLong("project_id"));
		return person;
	}
}

package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.TestTeam;

public interface TestTeamDAO {
	TestTeam getPersonById(Long id);

	List<TestTeam> getAllPersons();

	boolean deletePerson(TestTeam person);

	boolean updatePerson(TestTeam person);

	boolean createPerson(TestTeam person);
}

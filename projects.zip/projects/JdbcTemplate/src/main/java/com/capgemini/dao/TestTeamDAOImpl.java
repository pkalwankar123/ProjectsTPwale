package com.capgemini.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.capgemini.model.TestTeam;
import com.capgemini.model.TestTeamMapper;

@Component
public class TestTeamDAOImpl implements TestTeamDAO {

	JdbcTemplate jdbcTemplate;

	private final String SQL_FIND_PERSON = "select * from test_team where id = ?";
	private final String SQL_DELETE_PERSON = "delete from test_team where id = ?";
	private final String SQL_UPDATE_PERSON = "update test_team set name = ? where id = ?";
	private final String SQL_GET_ALL = "select * from test_team";
	private final String SQL_INSERT_PERSON = "insert into test_team(id,name, specification, salary, experience, project_id) values(?,?,?,?,?,?)";

	@Autowired
	public TestTeamDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public TestTeam getPersonById(Long id) {
		return jdbcTemplate.queryForObject(SQL_FIND_PERSON, new Object[] { id }, new TestTeamMapper());
	}

	public List<TestTeam> getAllPersons() {
		return jdbcTemplate.query(SQL_GET_ALL, new TestTeamMapper());
	}

	public boolean deletePerson(TestTeam person) {
		return jdbcTemplate.update(SQL_DELETE_PERSON, person.getId()) > 0;
	}

	public boolean updatePerson(TestTeam person) {
		return jdbcTemplate.update(SQL_UPDATE_PERSON, person.getName(), person.getId()) > 0;
	}

	public boolean createPerson(TestTeam person) {
		return jdbcTemplate.update(SQL_INSERT_PERSON, person.getId(), person.getName(), person.getSpecification(),
				person.getSalary(), person.getExperience(), person.getProjectId()) > 0;
	}
}

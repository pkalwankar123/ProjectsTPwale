package com.capgemini;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.config.Config;
import com.capgemini.dao.TestTeamDAO;
import com.capgemini.model.TestTeam;

public class Main {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);

		TestTeamDAO personDAO = context.getBean(TestTeamDAO.class);

		System.out.println("*****Team Details*****");

		for (TestTeam p : personDAO.getAllPersons()) {
			System.out.println(p);
		}

		System.out.println("*****Get By Id:2*****");

		TestTeam personById = personDAO.getPersonById(2L);
		System.out.println(personById);

		System.out.println("*****Creating New Teammate: ");
		TestTeam person = new TestTeam(13L, 20000L, "TEST", "TESTER", 2L, 2L);
		System.out.println(person);
		personDAO.createPerson(person);

		System.out.println("*****Team Details*****");
		for (TestTeam p : personDAO.getAllPersons()) {
			System.out.println(p);
		}

		System.out.println("Deleting Teammaten by ID 2");
		personDAO.deletePerson(personById);

		System.out.println("Update Teammate by ID 4");

		TestTeam pperson = personDAO.getPersonById(4L);
		System.out.println(pperson);
		pperson.setName("CHANGED");
		personDAO.updatePerson(pperson);

		System.out.println("*****Team Details*****");
		for (TestTeam p : personDAO.getAllPersons()) {
			System.out.println(p);
		}
		context.close();
	}
}

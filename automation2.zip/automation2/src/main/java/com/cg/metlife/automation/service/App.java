package com.cg.metlife.automation.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;

import java.util.Date;

import com.cg.metlife.automation.exceptions.Cursorclosedexception;

import oracle.jdbc.OracleTypes;

public class App 
{
	//final static String nmpolant="MTP169";
	  public static void main(String[] args) throws Exception  {
		   Connection conn = getOracleConnection();
		   String P_EMISIONStoredProcedure = "{ call P_EMISION(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		   CallableStatement callstmt = conn.prepareCall(P_EMISIONStoredProcedure);
		    conn.setAutoCommit(false);
		   
		   try {
		    	
			    callstmt.setString("USUARIO", "SEUS");
				    callstmt.setString("IDA_CARGAR", "26319081498");
				    callstmt.setString("P_COD_PROD", "PROV");
				    callstmt.setString("P_NMSOLICI", "26319081498");
				    callstmt.setString("TIPO", "G");
				    
				    callstmt.registerOutParameter("PN_NUMSERVICIO", java.sql.Types.NUMERIC);
				    callstmt.registerOutParameter("C_ERROR", OracleTypes.CURSOR);
				   
				    callstmt.registerOutParameter("CUMULOS", OracleTypes.CURSOR);
				    callstmt.registerOutParameter("ANTECEDENTES", OracleTypes.CURSOR);
				    callstmt.registerOutParameter("EDADESCOB", OracleTypes.CURSOR);
				    callstmt.registerOutParameter("CPLAN", OracleTypes.CURSOR);
				    callstmt.registerOutParameter("PARTNER", OracleTypes.CURSOR);
				    callstmt.registerOutParameter("CURSOR_OII", OracleTypes.CURSOR);
				    callstmt.registerOutParameter("CURSOR_PLAN2", OracleTypes.CURSOR);
				    
				    callstmt.registerOutParameter("STATUS", java.sql.Types.NUMERIC);
				    callstmt.registerOutParameter("FE_EMISION", java.sql.Types.DATE);
				    callstmt.registerOutParameter("PRIMA", java.sql.Types.NUMERIC);
				    callstmt.registerOutParameter("SUM_ASEG", java.sql.Types.NUMERIC);
				    
				   
				    callstmt.registerOutParameter("NMPOLANT",java.sql.Types.VARCHAR);
				    callstmt.setInt("PN_WORKCENTER_RETENDOR", 913);
				    callstmt.setInt("PN_WORKCENTER_UNITPAYMENT", 1);	 
			    
				    callstmt.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
				conn.rollback();
			}
		  
		   
		    
		    ResultSet rs1=null;
		    ResultSet rs2=null;
		    ResultSet rs3=null;
		    ResultSet rs4=null;
		    ResultSet rs5=null;
		    ResultSet rs6=null;
		    ResultSet rs7=null;
		    
		 
		   
		    try {
            ResultSet rs = (ResultSet)callstmt.getObject("C_ERROR");
            if(rs!=null){ 
            	while(rs.next()){           	
            		System.out.println("Hello"+rs.getString(1));
            		conn.rollback();
            		
               		}
            }
            else {
            	 try {
                     rs1 = (ResultSet)callstmt.getObject("CUMULOS");
                     	while(rs1.next()){
                     		System.out.println("CUMULOS"+rs1.getString(1));
                     		System.out.println("CUMULOS"+rs1.getString(2));
                     		System.out.println("CUMULOS"+rs1.getLong(3));
                     		System.out.println("CUMULOS"+rs1.getLong(4));
                     		System.out.println("CUMULOS"+rs1.getInt(5));
                     		System.out.println("CUMULOS"+rs1.getInt(6));
                     		System.out.println("CUMULOS"+rs1.getString(7));
                     		System.out.println("CUMULOS"+rs1.getString(8));
                     		System.out.println("CUMULOS"+rs1.getInt(9));
                     		System.out.println("CUMULOS"+rs1.getInt(10));
                     }
                     }catch(Exception e) {
                     	System.out.println(new Cursorclosedexception("CUMULOS" + "cursor is closed"));
                     }
                     
                     try {
                     rs2 = (ResultSet)callstmt.getObject("ANTECEDENTES");	
                     	while(rs2.next()){
                             System.out.println("ANTECEDENTES"+rs2.getString(1));
                             System.out.println("ANTECEDENTES"+rs2.getString(2));
                             System.out.println("ANTECEDENTES"+rs2.getString(3));             
                             System.out.println("ANTECEDENTES"+rs2.getDate(4));
                             System.out.println("ANTECEDENTES"+rs2.getDate(5));
                             System.out.println("ANTECEDENTES"+rs2.getInt(6));
                             System.out.println("ANTECEDENTES"+rs2.getString(7));
                             
                         }
                     }
                     catch(Exception e) {
                     		System.out.println(new Cursorclosedexception("ANTECEDENTES" + "cursor is closed"));
                     }
                     
                     try {
                     rs3 = (ResultSet)callstmt.getObject("EDADESCOB");	
                         while(rs3.next()){
                             System.out.println("EDADESCOB"+rs3.getString(1));
                             System.out.println("EDADESCOB"+rs3.getLong(2));
                             System.out.println("EDADESCOB"+rs3.getDouble(3));             
                             System.out.println("EDADESCOB"+rs3.getInt(4));
                             System.out.println("EDADESCOB"+rs3.getInt(5));
                             System.out.println("EDADESCOB"+rs3.getInt(6));
                             System.out.println("EDADESCOB"+rs3.getInt(7));
                             System.out.println("EDADESCOB"+rs3.getString(8));
                             System.out.println("EDADESCOB"+rs3.getInt(9));
                             System.out.println("EDADESCOB"+rs3.getString(10));
                             System.out.println("EDADESCOB"+rs3.getString(11));
                             
                         }
                         }
                         catch(Exception e) {
                         		System.out.println(new Cursorclosedexception("EDADESCOB" + "cursor is closed"));
                         }
                     
                     try {
                         rs4 = (ResultSet)callstmt.getObject("CPLAN");	
                         while(rs4.next()){
                             System.out.println("CPLAN"+rs4.getString(1));
                             System.out.println("CPLAN"+rs4.getString(2));
                         }
                         }
                         catch(Exception e) {
                         		System.out.println(new Cursorclosedexception("CPLAN" + "cursor is closed"));
                         }
                     
                     try {
                         rs5 = (ResultSet)callstmt.getObject("PARTNER");	
                         while(rs5.next()){
                         	System.out.println("Partner"+rs5.getString(1));
                             System.out.println("Partner"+rs5.getString(2));
                             System.out.println("Partner"+rs5.getDouble(3));             
                             System.out.println("Partner"+rs5.getString(4));
                             System.out.println("Partner"+rs5.getString(5));
                             System.out.println("Partner"+rs5.getString(6));
                             System.out.println("Partner"+rs5.getString(7));
                             System.out.println("Partner"+rs5.getString(8));
                             System.out.println("Partner"+rs5.getString(9));
                             System.out.println("Partner"+rs5.getString(10));
                             System.out.println("Partner"+rs5.getString(11));
                             System.out.println("Partner"+rs5.getString(12));
                             System.out.println("Partner"+rs5.getString(13));
                           
                         }
                         }
                         catch(Exception e) {
                         		System.out.println(new Cursorclosedexception("PARTNER" + "cursor is closed"));
                         }
                     
                     try {
                         rs6 = (ResultSet)callstmt.getObject("CURSOR_OII");	
                         while(rs6.next()){
                             System.out.println("OII"+rs6.getString(1));
                             System.out.println("OII"+rs6.getString(2));
                         }
                         }
                         catch(Exception e) {
                         		System.out.println(new Cursorclosedexception("CURSOR_OII" + "cursor is closed"));
                         }
                     
                     try {
                         rs7 = (ResultSet)callstmt.getObject("CURSOR_PLAN2");	
                         while(rs7.next()){
                         	System.out.println("plan"+rs7.getString(1));
                             System.out.println("plan"+rs7.getString(2));
                             System.out.println("plan"+rs7.getString(3));
                             System.out.println("plan"+rs7.getString(4));
                         }
                         }
                         catch(Exception e) {
                         		System.out.println(new Cursorclosedexception("CURSOR_PLAN2" + "cursor is closed"));
                         }
                     
                     
                     String plicyId=callstmt.getString("NMPOLANT");
             		//plicyId=nmpolant;
             		System.out.println("PolicyId is:"+"\t"+plicyId);
             		
             		
             int status=callstmt.getInt("STATUS");
             		System.out.println("status is:"+"\t"+status);
             		
             		
             Date feEmision=callstmt.getDate("FE_EMISION");
             		System.out.println("Date is:"+"\t"+feEmision);

             int prima=callstmt.getInt("PRIMA");
             		System.out.println("PRIMA is:"+"\t"+prima);
             
             int sumAseg=callstmt.getInt("SUM_ASEG");
             		System.out.println("SUM_ASEG is:"+"\t"+sumAseg);
             		
             		
             		conn.commit();
            }
            
            
		    }catch(Exception e) {
            	System.out.println(new Cursorclosedexception("C_ERROR" + "cursor is closed"));
            }
		    finally {
		    	conn.close();
		    }
           
         
	  }

            public static Connection getOracleConnection() throws Exception {
		    String driver = "oracle.jdbc.driver.OracleDriver";
		    String url = "jdbc:oracle:thin:@10.207.180.29:1521:ORCL11";
		    String username = "seus";
		    String password = "seus";

		    Class.forName(driver); 
		    Connection conn = DriverManager.getConnection(url, username, password);
		    return conn;
		  }
		}


package com.cg.metlife.automation.model;

import java.util.Date;

public class Coveragedata {
	private String COVERAGE_CONSIDERATION_FLG;
	private String COD_COBERTURA;
	private double SUMA_ASEGURADA;
	private int DICTAMEN_MEDICO;
	private int DICTAMEN_OCUPACIONAL;
	private double PRIMA;
	private int EXTRAPRIMA_MEDICA;
	private int EXTRAPRIMA_OCUPACIONAL;
	private String BENEFICIARIOS;
	private String BENEF_COMMENTS;
	private int TERM_COB;
	private int TIPO_LIQUIDATION;
	private int TIPO_PAQUETE;
	private int COD_ROL;
	private String RFC;
	private String CURP;
	private String AP_PATERNO;
	private String AP_MATERNO;
	private String NOMBRE;
	private Date FEC_NACIMIENTO;
	private String LUGAR_NAC;
	private String CVE_SEXO;
	private String EDO_CIVIL;
	private String CVE_FUMADOR;
	private double SUELDO_MENSUAL;
	private String OCUPACION;
	private String DET_OCUPACION;
	private String MOVIL;
	private int MEDIO_CNT;
	private int DIA_CNT;
	private int HORARIO_CNT;
	
	
	public String getCOVERAGE_CONSIDERATION_FLG() {
		return COVERAGE_CONSIDERATION_FLG;
	}
	public void setCOVERAGE_CONSIDERATION_FLG(String cOVERAGE_CONSIDERATION_FLG) {
		COVERAGE_CONSIDERATION_FLG = cOVERAGE_CONSIDERATION_FLG;
	}
	public String getCOD_COBERTURA() {
		return COD_COBERTURA;
	}
	public void setCOD_COBERTURA(String cOD_COBERTURA) {
		COD_COBERTURA = cOD_COBERTURA;
	}
	public double getSUMA_ASEGURADA() {
		return SUMA_ASEGURADA;
	}
	public void setSUMA_ASEGURADA(double sUMA_ASEGURADA) {
		SUMA_ASEGURADA = sUMA_ASEGURADA;
	}
	public int getDICTAMEN_MEDICO() {
		return DICTAMEN_MEDICO;
	}
	public void setDICTAMEN_MEDICO(int dICTAMEN_MEDICO) {
		DICTAMEN_MEDICO = dICTAMEN_MEDICO;
	}
	public int getDICTAMEN_OCUPACIONAL() {
		return DICTAMEN_OCUPACIONAL;
	}
	public void setDICTAMEN_OCUPACIONAL(int dICTAMEN_OCUPACIONAL) {
		DICTAMEN_OCUPACIONAL = dICTAMEN_OCUPACIONAL;
	}
	public double getPRIMA() {
		return PRIMA;
	}
	public void setPRIMA(double pRIMA) {
		PRIMA = pRIMA;
	}
	
	public int getEXTRAPRIMA_MEDICA() {
		return EXTRAPRIMA_MEDICA;
	}
	public void setEXTRAPRIMA_MEDICA(int eXTRAPRIMA_MEDICA) {
		EXTRAPRIMA_MEDICA = eXTRAPRIMA_MEDICA;
	}
	public int getEXTRAPRIMA_OCUPACIONAL() {
		return EXTRAPRIMA_OCUPACIONAL;
	}
	public void setEXTRAPRIMA_OCUPACIONAL(int eXTRAPRIMA_OCUPACIONAL) {
		EXTRAPRIMA_OCUPACIONAL = eXTRAPRIMA_OCUPACIONAL;
	}
	public String getBENEFICIARIOS() {
		return BENEFICIARIOS;
	}
	public void setBENEFICIARIOS(String bENEFICIARIOS) {
		BENEFICIARIOS = bENEFICIARIOS;
	}
	public String getBENEF_COMMENTS() {
		return BENEF_COMMENTS;
	}
	public void setBENEF_COMMENTS(String bENEF_COMMENTS) {
		BENEF_COMMENTS = bENEF_COMMENTS;
	}
	public int getTERM_COB() {
		return TERM_COB;
	}
	public void setTERM_COB(int tERM_COB) {
		TERM_COB = tERM_COB;
	}
	public int getTIPO_LIQUIDATION() {
		return TIPO_LIQUIDATION;
	}
	public void setTIPO_LIQUIDATION(int tIPO_LIQUIDATION) {
		TIPO_LIQUIDATION = tIPO_LIQUIDATION;
	}
	public int getTIPO_PAQUETE() {
		return TIPO_PAQUETE;
	}
	public void setTIPO_PAQUETE(int tIPO_PAQUETE) {
		TIPO_PAQUETE = tIPO_PAQUETE;
	}
	public int getCOD_ROL() {
		return COD_ROL;
	}
	public void setCOD_ROL(int cOD_ROL) {
		COD_ROL = cOD_ROL;
	}
	public String getRFC() {
		return RFC;
	}
	public void setRFC(String rFC) {
		RFC = rFC;
	}
	public String getCURP() {
		return CURP;
	}
	public void setCURP(String cURP) {
		CURP = cURP;
	}
	public String getAP_PATERNO() {
		return AP_PATERNO;
	}
	public void setAP_PATERNO(String aP_PATERNO) {
		AP_PATERNO = aP_PATERNO;
	}
	public String getAP_MATERNO() {
		return AP_MATERNO;
	}
	public void setAP_MATERNO(String aP_MATERNO) {
		AP_MATERNO = aP_MATERNO;
	}
	public String getNOMBRE() {
		return NOMBRE;
	}
	public void setNOMBRE(String nOMBRE) {
		NOMBRE = nOMBRE;
	}
	public Date getFEC_NACIMIENTO() {
		return FEC_NACIMIENTO;
	}
	public void setFEC_NACIMIENTO(Date fEC_NACIMIENTO) {
		FEC_NACIMIENTO = fEC_NACIMIENTO;
	}
	public String getLUGAR_NAC() {
		return LUGAR_NAC;
	}
	public void setLUGAR_NAC(String lUGAR_NAC) {
		LUGAR_NAC = lUGAR_NAC;
	}
	public String getCVE_SEXO() {
		return CVE_SEXO;
	}
	public void setCVE_SEXO(String cVE_SEXO) {
		CVE_SEXO = cVE_SEXO;
	}
	public String getEDO_CIVIL() {
		return EDO_CIVIL;
	}
	public void setEDO_CIVIL(String eDO_CIVIL) {
		EDO_CIVIL = eDO_CIVIL;
	}
	public String getCVE_FUMADOR() {
		return CVE_FUMADOR;
	}
	public void setCVE_FUMADOR(String cVE_FUMADOR) {
		CVE_FUMADOR = cVE_FUMADOR;
	}
	public double getSUELDO_MENSUAL() {
		return SUELDO_MENSUAL;
	}
	public void setSUELDO_MENSUAL(double sUELDO_MENSUAL) {
		SUELDO_MENSUAL = sUELDO_MENSUAL;
	}
	public String getOCUPACION() {
		return OCUPACION;
	}
	public void setOCUPACION(String oCUPACION) {
		OCUPACION = oCUPACION;
	}
	public String getDET_OCUPACION() {
		return DET_OCUPACION;
	}
	public void setDET_OCUPACION(String dET_OCUPACION) {
		DET_OCUPACION = dET_OCUPACION;
	}
	public String getMOVIL() {
		return MOVIL;
	}
	public void setMOVIL(String mOVIL) {
		MOVIL = mOVIL;
	}
	public int getMEDIO_CNT() {
		return MEDIO_CNT;
	}
	public void setMEDIO_CNT(int mEDIO_CNT) {
		MEDIO_CNT = mEDIO_CNT;
	}
	public int getDIA_CNT() {
		return DIA_CNT;
	}
	public void setDIA_CNT(int dIA_CNT) {
		DIA_CNT = dIA_CNT;
	}
	public int getHORARIO_CNT() {
		return HORARIO_CNT;
	}
	public void setHORARIO_CNT(int hORARIO_CNT) {
		HORARIO_CNT = hORARIO_CNT;
	}
	@Override
	public String toString() {
		return "COVERAGE_DATA [COVERAGE_CONSIDERATION_FLG=" + COVERAGE_CONSIDERATION_FLG + ", COD_COBERTURA="
				+ COD_COBERTURA + ", SUMA_ASEGURADA=" + SUMA_ASEGURADA + ", DICTAMEN_MEDICO=" + DICTAMEN_MEDICO
				+ ", DICTAMEN_OCUPACIONAL=" + DICTAMEN_OCUPACIONAL + ", PRIMA=" + PRIMA + ", EXTRAPRIMA_MEDICA="
				+ EXTRAPRIMA_MEDICA + ", EXTRAPRIMA_OCUPACIONAL=" + EXTRAPRIMA_OCUPACIONAL + ", BENEFICIARIOS="
				+ BENEFICIARIOS + ", BENEF_COMMENTS=" + BENEF_COMMENTS + ", TERM_COB=" + TERM_COB
				+ ", TIPO_LIQUIDATION=" + TIPO_LIQUIDATION + ", TIPO_PAQUETE=" + TIPO_PAQUETE + ", COD_ROL=" + COD_ROL
				+ ", RFC=" + RFC + ", CURP=" + CURP + ", AP_PATERNO=" + AP_PATERNO + ", AP_MATERNO=" + AP_MATERNO
				+ ", NOMBRE=" + NOMBRE + ", FEC_NACIMIENTO=" + FEC_NACIMIENTO + ", LUGAR_NAC=" + LUGAR_NAC
				+ ", CVE_SEXO=" + CVE_SEXO + ", EDO_CIVIL=" + EDO_CIVIL + ", CVE_FUMADOR=" + CVE_FUMADOR
				+ ", SUELDO_MENSUAL=" + SUELDO_MENSUAL + ", OCUPACION=" + OCUPACION + ", DET_OCUPACION=" + DET_OCUPACION
				+ ", MOVIL=" + MOVIL + ", MEDIO_CNT=" + MEDIO_CNT + ", DIA_CNT=" + DIA_CNT + ", HORARIO_CNT="
				+ HORARIO_CNT + "]";
	}
	
	
	
	
	
	
	

}

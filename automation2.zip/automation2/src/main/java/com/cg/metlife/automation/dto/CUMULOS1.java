package com.cg.metlife.automation.dto;

public class CUMULOS1 {
	private String code;
	private long faceamount;
	private long faceamountpesos;
	private int medicalextrapremiumfactor;
	private int jobdictumfactor;
	private String policynumber;
	private String planname;
	private int medicalemr;
	private int PAYMENT_FREQUENCY;
	
	public CUMULOS1() {}
	
	
	public CUMULOS1(String name, String code, long faceamount, long faceamountpesos, int medicalextrapremiumfactor,
			int jobdictumfactor, String policynumber, String planname, int medicalemr, int pAYMENT_FREQUENCY) {
		super();
		this.name = name;
		this.code = code;
		this.faceamount = faceamount;
		this.faceamountpesos = faceamountpesos;
		this.medicalextrapremiumfactor = medicalextrapremiumfactor;
		this.jobdictumfactor = jobdictumfactor;
		this.policynumber = policynumber;
		this.planname = planname;
		this.medicalemr = medicalemr;
		PAYMENT_FREQUENCY = pAYMENT_FREQUENCY;
	}

	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public long getFaceamount() {
		return faceamount;
	}

	public void setFaceamount(long faceamount) {
		this.faceamount = faceamount;
	}

	public long getFaceamountpesos() {
		return faceamountpesos;
	}

	public void setFaceamountpesos(long faceamountpesos) {
		this.faceamountpesos = faceamountpesos;
	}

	public int getMedicalextrapremiumfactor() {
		return medicalextrapremiumfactor;
	}

	public void setMedicalextrapremiumfactor(int medicalextrapremiumfactor) {
		this.medicalextrapremiumfactor = medicalextrapremiumfactor;
	}

	public int getJobdictumfactor() {
		return jobdictumfactor;
	}

	public void setJobdictumfactor(int jobdictumfactor) {
		this.jobdictumfactor = jobdictumfactor;
	}

	public String getPolicynumber() {
		return policynumber;
	}

	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}

	public String getPlanname() {
		return planname;
	}

	public void setPlanname(String planname) {
		this.planname = planname;
	}

	public int getMedicalemr() {
		return medicalemr;
	}

	public void setMedicalemr(int medicalemr) {
		this.medicalemr = medicalemr;
	}

	public int getPAYMENT_FREQUENCY() {
		return PAYMENT_FREQUENCY;
	}

	public void setPAYMENT_FREQUENCY(int pAYMENT_FREQUENCY) {
		PAYMENT_FREQUENCY = pAYMENT_FREQUENCY;
	}


	@Override
	public String toString() {
		return "CUMULOS [code=" + code + ", faceamount=" + faceamount + ", faceamountpesos=" + faceamountpesos
				+ ", medicalextrapremiumfactor=" + medicalextrapremiumfactor + ", jobdictumfactor=" + jobdictumfactor
				+ ", policynumber=" + policynumber + ", planname=" + planname + ", medicalemr=" + medicalemr
				+ ", PAYMENT_FREQUENCY=" + PAYMENT_FREQUENCY + ", name=" + name + "]";
	}

	
	
	
	
	
	
}

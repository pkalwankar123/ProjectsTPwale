package com.cg.metlife.automation.model;

import java.util.HashMap;

public class DesSolicitudes {
private char TIPO_ID;
private int CVE_STATUS;
private int MONEDA;
private int CVE_FORMA_PAGO;
private char MESA_GUARDIA;
private String CVE_USUARIO;
private String PROMOTORIA;
private String ZONA_PROM;
private HashMap<String, String> newEntries;


public char getTIPO_ID() {
	return TIPO_ID;
}
public void setTIPO_ID(char tIPO_ID) {
	TIPO_ID = tIPO_ID;
}
public int getCVE_STATUS() {
	return CVE_STATUS;
}
public void setCVE_STATUS(int cVE_STATUS) {
	CVE_STATUS = cVE_STATUS;
}
public int getMONEDA() {
	return MONEDA;
}
public void setMONEDA(int mONEDA) {
	MONEDA = mONEDA;
}
public int getCVE_FORMA_PAGO() {
	return CVE_FORMA_PAGO;
}
public void setCVE_FORMA_PAGO(int cVE_FORMA_PAGO) {
	CVE_FORMA_PAGO = cVE_FORMA_PAGO;
}
public char getMESA_GUARDIA() {
	return MESA_GUARDIA;
}
public void setMESA_GUARDIA(char mESA_GUARDIA) {
	MESA_GUARDIA = mESA_GUARDIA;
}
public String getCVE_USUARIO() {
	return CVE_USUARIO;
}
public void setCVE_USUARIO(String cVE_USUARIO) {
	CVE_USUARIO = cVE_USUARIO;
}
public String getPROMOTORIA() {
	return PROMOTORIA;
}
public void setPROMOTORIA(String pROMOTORIA) {
	PROMOTORIA = pROMOTORIA;
}
public String getZONA_PROM() {
	return ZONA_PROM;
}
public void setZONA_PROM(String zONA_PROM) {
	ZONA_PROM = zONA_PROM;
}
public HashMap<String, String> getNewEntries() {
	return newEntries;
}
public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}
@Override
public String toString() {
	return "DES_SOLICITUDES [TIPO_ID=" + TIPO_ID + ", CVE_STATUS=" + CVE_STATUS + ", MONEDA=" + MONEDA
			+ ", CVE_FORMA_PAGO=" + CVE_FORMA_PAGO + ", MESA_GUARDIA=" + MESA_GUARDIA + ", CVE_USUARIO=" + CVE_USUARIO
			+ ", PROMOTORIA=" + PROMOTORIA + ", ZONA_PROM=" + ZONA_PROM + ", newEntries=" + newEntries + "]";
}


}

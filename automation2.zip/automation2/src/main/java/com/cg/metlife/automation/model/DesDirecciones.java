package com.cg.metlife.automation.model;

import java.util.HashMap;

public class DesDirecciones {
private int SEQ;
private int TIP_DIR;
private String CALLE;
private String COLONIA;
private int NUMEXT;
private int ESTADO;
private HashMap<String, String> newEntries;


public int getSEQ() {
	return SEQ;
}
public void setSEQ(int sEQ) {
	SEQ = sEQ;
}
public int getTIP_DIR() {
	return TIP_DIR;
}
public void setTIP_DIR(int tIP_DIR) {
	TIP_DIR = tIP_DIR;
}
public String getCALLE() {
	return CALLE;
}
public void setCALLE(String cALLE) {
	CALLE = cALLE;
}
public String getCOLONIA() {
	return COLONIA;
}
public void setCOLONIA(String cOLONIA) {
	COLONIA = cOLONIA;
}
public int getNUMEXT() {
	return NUMEXT;
}
public void setNUMEXT(int nUMEXT) {
	NUMEXT = nUMEXT;
}
public int getESTADO() {
	return ESTADO;
}
public void setESTADO(int eSTADO) {
	ESTADO = eSTADO;
}



public HashMap<String, String> getNewEntries() {
	return newEntries;
}
public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}
@Override
public String toString() {
	return "DES_DIRECCIONES [SEQ=" + SEQ + ", TIP_DIR=" + TIP_DIR + ", CALLE=" + CALLE + ", COLONIA=" + COLONIA
			+ ", NUMEXT=" + NUMEXT + ", ESTADO=" + ESTADO + ", newEntries=" + newEntries + "]";
}
 





}

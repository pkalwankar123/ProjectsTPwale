package com.cg.metlife.automation.Enums;

public enum VdevcoverageEnum {
	VDEVRequired
}

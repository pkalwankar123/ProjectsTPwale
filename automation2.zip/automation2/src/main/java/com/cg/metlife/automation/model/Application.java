package com.cg.metlife.automation.model;

import java.util.Set;

public class Application {
	
	private Long id;
	private String nmpolant;
	private String codProducto;
	private  String codPlan;
	private DesAgent desAgent;
	private DesCorreos desCorreos;
	private DesDirecciones desDirecciones;
	private DesPlanes desPlanes;
	private DesSolicitudes desSolicitudes;
	private DesCobranza desCobranza;
	private VdevCoverageflag vedevCoverageFlag;
	private Set<Coveragedata> covData;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNmpolant() {
		return nmpolant;
	}
	public void setNmpolant(String nmpolant) {
		this.nmpolant = nmpolant;
	}
	public String getCodProducto() {
		return codProducto;
	}
	public void setCodProducto(String codProducto) {
		this.codProducto = codProducto;
	}
	public String getCodPlan() {
		return codPlan;
	}
	public void setCodPlan(String codPlan) {
		this.codPlan = codPlan;
	}
	
	
	public DesAgent getDesAgent() {
		return desAgent;
	}
	public void setDesAgent(DesAgent desAgent) {
		this.desAgent = desAgent;
	}
	
	
	public DesCorreos getDesCorreos() {
		return desCorreos;
	}
	public void setDesCorreos(DesCorreos desCorreos) {
		this.desCorreos = desCorreos;
	}
	
	
	public DesDirecciones getDesDirecciones() {
		return desDirecciones;
	}
	public void setDesDirecciones(DesDirecciones desDirecciones) {
		this.desDirecciones = desDirecciones;
	}
	public DesPlanes getDesPlanes() {
		return desPlanes;
	}
	public void setDesPlanes(DesPlanes desPlanes) {
		this.desPlanes = desPlanes;
	}
	public DesSolicitudes getDesSolicitudes() {
		return desSolicitudes;
	}
	public void setDesSolicitudes(DesSolicitudes desSolicitudes) {
		this.desSolicitudes = desSolicitudes;
	}
	public DesCobranza getDesCobranza() {
		return desCobranza;
	}
	public void setDesCobranza(DesCobranza desCobranza) {
		this.desCobranza = desCobranza;
	}

	public VdevCoverageflag getVedevCoverageFlag() {
		return vedevCoverageFlag;
	}
	public void setVedevCoverageFlag(VdevCoverageflag vedevCoverageFlag) {
		this.vedevCoverageFlag = vedevCoverageFlag;
	}
	public Set<Coveragedata> getCovData() {
		return covData;
	}
	public void setCovData(Set<Coveragedata> covData) {
		this.covData = covData;
	}
	@Override
	public String toString() {
		return "Application [id=" + id + ", nmpolant=" + nmpolant + ", codProducto=" + codProducto + ", codPlan="
				+ codPlan + ", desAgent=" + desAgent + ", desCorreos=" + desCorreos + ", desDirecciones="
				+ desDirecciones + ", desPlanes=" + desPlanes + ", desSolicitudes=" + desSolicitudes + ", desCobranza="
				+ desCobranza + ", vedevCoverageFlag=" + vedevCoverageFlag + ", covData=" + covData + "]";
	}
	
	
}

package com.cg.metlife.automation.model;

import java.util.HashMap;

public class DesCorreos {
private String EMAIL;
private int TIPO_EMAIL; 
private int SEQ;
private String EMAIL_NOTIFICAR;
private HashMap<String, String> newEntries;

public String getEMAIL() {
	return EMAIL;
}
public void setEMAIL(String eMAIL) {
	EMAIL = eMAIL;
}


public int getTIPO_EMAIL() {
	return TIPO_EMAIL;
}
public void setTIPO_EMAIL(int tIPO_EMAIL) {
	TIPO_EMAIL = tIPO_EMAIL;
}
public int getSEQ() {
	return SEQ;
}
public void setSEQ(int sEQ) {
	SEQ = sEQ;
}
public String getEMAIL_NOTIFICAR() {
	return EMAIL_NOTIFICAR;
}
public void setEMAIL_NOTIFICAR(String eMAIL_NOTIFICAR) {
	EMAIL_NOTIFICAR = eMAIL_NOTIFICAR;
}


public HashMap<String, String> getNewEntries() {
	return newEntries;
}
public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}
@Override
public String toString() {
	return "DES_CORREOS [EMAIL=" + EMAIL + ", TIPO_EMAIL=" + TIPO_EMAIL + ", SEQ=" + SEQ + ", EMAIL_NOTIFICAR="
			+ EMAIL_NOTIFICAR + ", newEntries=" + newEntries + "]";
}




}

package com.cg.metlife.automation.Enums;

public enum DesTableEnum {
	ZWNPOLAN,
	DES_AGENTES,
	DES_SOLICITUDES,
	DES_DIRECCIONES,
	DES_PLANES,
	DES_CORREOS,
	DES_COBRANZA,
	DES_COBERTURAS,
	DES_PERSONAS
}

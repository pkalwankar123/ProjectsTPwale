package com.cg.metlife.automation.model;

import java.math.BigInteger;
import java.util.HashMap;

public class DesCobranza {
private int	RETENEDOR;
private int	UNIDADPGO;
private int	CONCEPTO;
private int	CONDUCTO_COBRO;
private BigInteger	ID_NOMINAL;
private String	NUM_CUENTA;
private String	CLAVE_BANCO;
private String	SUCURSAL;
private int	ENT_FED;
private String	LABOR_REGIME;
private String	ADSCRIPCION;
private int	RETENEDOR_CT;
private int	UNIDADPGO_CT;
private HashMap<String, String> newEntries;


public int getRETENEDOR() {
	return RETENEDOR;
}
public void setRETENEDOR(int rETENEDOR) {
	RETENEDOR = rETENEDOR;
}
public int getUNIDADPGO() {
	return UNIDADPGO;
}
public void setUNIDADPGO(int uNIDADPGO) {
	UNIDADPGO = uNIDADPGO;
}
public int getCONCEPTO() {
	return CONCEPTO;
}
public void setCONCEPTO(int cONCEPTO) {
	CONCEPTO = cONCEPTO;
}
public int getCONDUCTO_COBRO() {
	return CONDUCTO_COBRO;
}
public void setCONDUCTO_COBRO(int cONDUCTO_COBRO) {
	CONDUCTO_COBRO = cONDUCTO_COBRO;
}
public BigInteger getID_NOMINAL() {
	return ID_NOMINAL;
}
public void setID_NOMINAL(BigInteger iD_NOMINAL) {
	ID_NOMINAL = iD_NOMINAL;
}
public String getNUM_CUENTA() {
	return NUM_CUENTA;
}
public void setNUM_CUENTA(String nUM_CUENTA) {
	NUM_CUENTA = nUM_CUENTA;
}
public String getCLAVE_BANCO() {
	return CLAVE_BANCO;
}
public void setCLAVE_BANCO(String cLAVE_BANCO) {
	CLAVE_BANCO = cLAVE_BANCO;
}
public String getSUCURSAL() {
	return SUCURSAL;
}
public void setSUCURSAL(String sUCURSAL) {
	SUCURSAL = sUCURSAL;
}
public int getENT_FED() {
	return ENT_FED;
}
public void setENT_FED(int eNT_FED) {
	ENT_FED = eNT_FED;
}
public String getLABOR_REGIME() {
	return LABOR_REGIME;
}
public void setLABOR_REGIME(String lABOR_REGIME) {
	LABOR_REGIME = lABOR_REGIME;
}
public String getADSCRIPCION() {
	return ADSCRIPCION;
}
public void setADSCRIPCION(String aDSCRIPCION) {
	ADSCRIPCION = aDSCRIPCION;
}
public int getRETENEDOR_CT() {
	return RETENEDOR_CT;
}
public void setRETENEDOR_CT(int rETENEDOR_CT) {
	RETENEDOR_CT = rETENEDOR_CT;
}
public int getUNIDADPGO_CT() {
	return UNIDADPGO_CT;
}
public void setUNIDADPGO_CT(int uNIDADPGO_CT) {
	UNIDADPGO_CT = uNIDADPGO_CT;
}
public HashMap<String, String> getNewEntries() {
	return newEntries;
}
public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}
@Override
public String toString() {
	return "DES_COBRANZA [RETENEDOR=" + RETENEDOR + ", UNIDADPGO=" + UNIDADPGO + ", CONCEPTO=" + CONCEPTO
			+ ", CONDUCTO_COBRO=" + CONDUCTO_COBRO + ", ID_NOMINAL=" + ID_NOMINAL + ", NUM_CUENTA=" + NUM_CUENTA
			+ ", CLAVE_BANCO=" + CLAVE_BANCO + ", SUCURSAL=" + SUCURSAL + ", ENT_FED=" + ENT_FED + ", LABOR_REGIME="
			+ LABOR_REGIME + ", ADSCRIPCION=" + ADSCRIPCION + ", RETENEDOR_CT=" + RETENEDOR_CT + ", UNIDADPGO_CT="
			+ UNIDADPGO_CT + ", newEntries=" + newEntries + "]";
}








}

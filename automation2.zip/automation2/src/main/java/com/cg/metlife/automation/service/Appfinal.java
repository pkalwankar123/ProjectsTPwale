package com.cg.metlife.automation.service;



import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.metlife.automation.model.Application;


public class Appfinal 
{

	
	//final static String nmpolant="MTP169";
	  public static void main(String args[]) throws Exception  {
		  //Appfinal rd=new Appfinal();
		 // finale fi=new finale();
		  //fi.getApplication();
		  //System.out.println(fi.getApplication());*/
		  //rd.selectData(application);
		 // System.out.println(f.getApplication().getId());
		 Connection conn = getOracleConnection();
		   String P_EMISIONStoredProcedure = "{ call test_prd_emi(?) }";
		   CallableStatement callstmt = conn.prepareCall(P_EMISIONStoredProcedure);
		    try {	
			    callstmt.setString("p_id", "26319081465");
				     //System.out.println(Long.toString(application.getId()));
			    
				    callstmt.execute();
				    conn.commit();
				  //selectData(application);
				
		} catch (Exception e) {
				e.printStackTrace();
			}
		    finally {
		    	conn.close();
		    }
  }

	  
	  
	  
	  public static void selectData(Application application) throws Exception {
			
		  
		  
		  Connection conn = null;
			
			
				try {
					conn = getOracleConnection();
					
					PreparedStatement zwpolanDel=conn.prepareStatement("select  * from mpolizas where nmsolici=?");
					
					zwpolanDel.setLong(1, application.getId());
					ResultSet r=zwpolanDel.executeQuery();

					 while (r.next()) {  
						 int re=r.getInt("NMPOLIZA");

			System.out.println(re);		    
					 }

					
					
					
				} catch (Exception e) {
					
					e.printStackTrace();
				}
				finally {
					try {
						conn.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
				}
		}
	  
	  

            public static Connection getOracleConnection() throws Exception {
		    String driver = "oracle.jdbc.driver.OracleDriver";
		    String url = "jdbc:oracle:thin:@10.207.180.29:1521:ORCL11";
		    String username = "seus";
		    String password = "seus";

		    Class.forName(driver); 
		    Connection conn = DriverManager.getConnection(url, username, password);
		    return conn;
		  }
		}


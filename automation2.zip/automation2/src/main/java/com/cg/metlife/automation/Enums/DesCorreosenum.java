package com.cg.metlife.automation.Enums;

public enum DesCorreosenum {

	EMAIL,
	TIPO_EMAIL, 
	SEQ,
	EMAIL_NOTIFICAR
	
}

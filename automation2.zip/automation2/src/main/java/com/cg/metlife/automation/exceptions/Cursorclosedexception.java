package com.cg.metlife.automation.exceptions;

public class Cursorclosedexception extends Exception{

	
	public Cursorclosedexception() {}
	
	public Cursorclosedexception(String msg) {
		super(msg);
	}
	
}

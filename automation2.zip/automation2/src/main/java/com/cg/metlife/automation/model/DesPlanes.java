package com.cg.metlife.automation.model;

import java.util.HashMap;

public class DesPlanes {
private int APORTACION;
private HashMap<String, String> newEntries;

public int getAPORTACION() {
	return APORTACION;
}

public void setAPORTACION(int aPORTACION) {
	APORTACION = aPORTACION;
}

public HashMap<String, String> getNewEntries() {
	return newEntries;
}

public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}

@Override
public String toString() {
	return "DES_PLANES [APORTACION=" + APORTACION + ", newEntries=" + newEntries + "]";
}




}

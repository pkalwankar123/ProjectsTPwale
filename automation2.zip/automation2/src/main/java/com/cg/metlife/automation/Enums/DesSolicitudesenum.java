package com.cg.metlife.automation.Enums;

public enum DesSolicitudesenum {
	TIPO_ID,
	CVE_STATUS,
	MONEDA,
	CVE_FORMA_PAGO,
	MESA_GUARDIA,
	CVE_USUARIO,
	PROMOTORIA,
	ZONA_PROM
}

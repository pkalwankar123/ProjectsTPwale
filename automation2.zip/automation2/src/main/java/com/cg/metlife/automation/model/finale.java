package com.cg.metlife.automation.model;

public class finale {
private Application application;

public Application getApplication() {
	return application;
}

public void setApplication(Application application) {
	this.application = application;
}

@Override
public String toString() {
	return "finale [application=" + application + "]";
}



}

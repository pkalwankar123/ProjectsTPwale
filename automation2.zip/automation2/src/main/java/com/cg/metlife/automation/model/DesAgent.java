package com.cg.metlife.automation.model;

import java.util.HashMap;

public class DesAgent {
private char TIPO_AGENTE;
private int AGENTE;
private String PORCENTAJE;
private HashMap<String, String> newEntries;

public char getTIPO_AGENTE() {
	return TIPO_AGENTE;
}
public void setTIPO_AGENTE(char tIPO_AGENTE) {
	TIPO_AGENTE = tIPO_AGENTE;
}
public int getAGENTE() {
	return AGENTE;
}
public void setAGENTE(int aGENTE) {
	AGENTE = aGENTE;
}
public String getPORCENTAJE() {
	return PORCENTAJE;
}
public void setPORCENTAJE(String pORCENTAJE) {
	PORCENTAJE = pORCENTAJE;
}


public HashMap<String, String> getNewEntries() {
	return newEntries;
}
public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}
@Override
public String toString() {
	return "DESAgent [TIPO_AGENTE=" + TIPO_AGENTE + ", AGENTE=" + AGENTE + ", PORCENTAJE=" + PORCENTAJE
			+ ", newEntries=" + newEntries + "]";
}






}

package com.cg.metlife.automation.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Readfile2 {
	
	public static void main(String args[]) {
	java.util.Date dtae=new java.util.Date();
	System.out.println(dtae);
	}
	/*
        static int counterEnum=0;
        
        static Connection conn=null;
	   static  {
		  		Properties prop = new Properties();
			    try (InputStream input = Readfile2.class.getClassLoader().getResourceAsStream("application.properties")) {	            
		            prop.load(input);
		            Class.forName(prop.getProperty("db.driver")); 
				    conn = DriverManager.getConnection(prop.getProperty("db.url"), prop.getProperty("db.username"), prop.getProperty("db.password"));
		        } catch (IOException | SQLException | ClassNotFoundException ex) {
		            ex.printStackTrace();
		        }
				

		    }

		public static boolean isRowEmpty(Row row){
			if(row==null) {
				return true;
			}
	         int firstCol = row.getFirstCellNum();
	         for(int cnt = 0; cnt<4 ; cnt++){
	             Cell cell = row.getCell(firstCol+cnt);
	             if(cell!=null && cell.getCellType()!=Cell.CELL_TYPE_BLANK){
	                 return false;
	             }
	         }
	         return true;
	    }

		public static void main(String[] args) throws Exception 
	    {

	    	
	        try(InputStream input = Readfile2.class.getClassLoader().getResourceAsStream("application.properties"))
	        {
	        	Properties prop = new Properties();
	        	prop.load(input);
	            FileInputStream file = new FileInputStream(new File(prop.getProperty("filePath")));
	           
	            XSSFWorkbook workbook = new XSSFWorkbook(file);
	            XSSFSheet sheet = workbook.getSheetAt(0);


	   
	            for(int rowCount=sheet.getFirstRowNum();rowCount<=sheet.getLastRowNum();rowCount++) { 
	        	   if(!isRowEmpty(sheet.getRow(rowCount))) {  
	        	 DataFormatter formatter = new DataFormatter();
	            	String rowValue = formatter.formatCellValue(sheet.getRow(rowCount).getCell(0));
	            	System.out.println("jsdhjfgdskjgfkjsgekjfgaskjgf");
	            	//String tableEnum=DesTableEnum.values()[counterEnum].toString();
	            	
	            	switch (rowValue) {
	            	case "ZWNPOLAN":
	            		rowCount=insertZwnpolan(sheet,rowCount,formatter);
	            		break;
	            	case "DES_AGENTES":
	            		rowCount=insertDesAgentes(sheet,rowCount,formatter);
	            		break;
	            	case "DES_SOLICITUDES":
	            		rowCount=insertDesSolicitudes(sheet,rowCount,formatter);
	            		break;
	            		case "DES_DIRECCIONES":
	            		desCommonRead(sheet, formatter, rowValue, tableEnum);
	            		break;
	            	case "DES_PLANES":
	            		desCommonRead(sheet, formatter, rowValue, tableEnum);
	            		break;
	            	case "DES_CORREOS":
	            		desCommonRead(sheet, formatter, rowValue, tableEnum);
	            		break;
	            	case "DES_COBRANZA":
	            		desCommonRead(sheet, formatter, rowValue, tableEnum);
	            		break;
	            	case "DES_COBERTURAS":
	            		desCommonRead(sheet, formatter, rowValue, tableEnum);
	            		break;
	            	case "DES_PERSONAS":
	            		desCommonRead(sheet, formatter, rowValue, tableEnum);
	            		break;
	            	default:
	            		System.out.println(rowValue+":NOT FOUND");
	            	}

	            	}	            	
	        	   }
	            conn.commit();
	        } catch (IOException e) {
	        	conn.rollback();
				e.printStackTrace();
			}

	        }
		
		private static int insertDesAgentes(XSSFSheet sheet, int rowCount2, DataFormatter formatter) throws Exception {
			
			
			rowCount2++;
			while(!isRowEmpty(sheet.getRow(++rowCount2))) {
				int ii=0;
				PreparedStatement desAgenteIns = conn.prepareStatement("INSERT INTO DES_AGENTES VALUES (?,?,?,?,?,?)");
				
				    desAgenteIns.setString(1, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(ii)));
			        desAgenteIns.setString(2, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
			        desAgenteIns.setString(3, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
			        desAgenteIns.setString(4, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
			        desAgenteIns.setInt(5, Integer.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
			        desAgenteIns.setString(6, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
			        desAgenteIns.executeUpdate();
System.out.println("hello");
			}	
		
				return rowCount2;	
					
				}

private static int insertDesSolicitudes(XSSFSheet sheet, int rowCount2, DataFormatter formatter) throws Exception {
	
	rowCount2++;
	while(!isRowEmpty(sheet.getRow(++rowCount2))) {
		int ii=0;
	
	
	PreparedStatement desSolicitudesIns = conn.prepareStatement("INSERT INTO DES_SOLICITUDES VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

     desSolicitudesIns.setString(1, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(ii)));
     desSolicitudesIns.setString(2, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(3, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(4, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setInt(5, Integer.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setInt(6, Integer.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setDate(7, Date.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setDate(8, Date.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setDate(9, Date.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setDate(10, Date.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setDate(11, Date.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setDate(12, Date.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setInt(13, Integer.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setInt(14, Integer.valueOf(formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii))));
     desSolicitudesIns.setString(15, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(16, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(17, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(18, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(19, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.setString(20, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
     desSolicitudesIns.executeUpdate();
	}	
return rowCount2;
		}



private static int insertZwnpolan(XSSFSheet sheet, int rowCount2, DataFormatter formatter) throws Exception {
	

	rowCount2++;
	while(!isRowEmpty(sheet.getRow(++rowCount2))) {
		int ii=0;
		PreparedStatement zwpolanIns = conn.prepareStatement("INSERT INTO ZWNPOLAN VALUES (?, ?)");
	        zwpolanIns.setString(1,formatter.formatCellValue(sheet.getRow(rowCount2).getCell(ii)));
	        zwpolanIns.setString(2, formatter.formatCellValue(sheet.getRow(rowCount2).getCell(++ii)));
	        zwpolanIns.executeUpdate();	

	}	
	return rowCount2;
}

private static void desCommonRead(XSSFSheet sheet, DataFormatter formatter, String rowValue, String tableEnum) {
	if(rowValue.equalsIgnoreCase(tableEnum)) {
		rowCount=rowCount+2;
		HashMap<Integer, String> rowValues=new HashMap<Integer, String>();
		HashMap<Integer, HashMap<Integer, String>> finalKeyValuePair=new HashMap<Integer, HashMap<Integer, String>>();
		while(isRowEmpty(sheet.getRow(rowCount))==false) {
			AtomicInteger atomicInteger = new AtomicInteger();
			short length=sheet.getRow(rowCount).getLastCellNum();
			for(int j=0;j<length;j++) {
				Integer number=atomicInteger.getAndIncrement();
				String tableValue = formatter.formatCellValue(sheet.getRow(rowCount).getCell(j));
				rowValues.put(number, tableValue);
									}
				finalKeyValuePair.put(atomicInteger.getAndIncrement(), rowValues);
				System.out.println(rowValues);
				rowCount++;
				}
        }
	++counterEnum;
}

		
		private static Date parse(String pattern,String dateString) {
			if(dateString == null || dateString.isEmpty()) return null;

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			Date date = null;
			try {
				date = simpleDateFormat.parse(dateString);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			return date;
		}
		
		private static String format(String pattern,Date date) {
			if(date == null) return null;

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			return simpleDateFormat.format(date);
		}
		
		
			
public static boolean isCellDateFormatted(Cell cell) {
    if (cell == null) return false;
    boolean bDate = false;
        CellStyle style = cell.getCellStyle();
        if(style==null) return false;
        int i = style.getDataFormat();
        String f = style.getDataFormatString();
        bDate = DateUtil.isADateFormat(i, f);
    return bDate;
}	*/				
}			
			
			
			
			
			
			
	


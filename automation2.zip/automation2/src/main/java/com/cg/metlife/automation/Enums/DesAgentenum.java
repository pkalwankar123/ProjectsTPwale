package com.cg.metlife.automation.Enums;

public enum DesAgentenum {
	TIPO_AGENTE,
	AGENTE,
	PORCENTAJE
}

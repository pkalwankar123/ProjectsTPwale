package com.cg.metlife.automation.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cg.metlife.automation.Enums.Coverageenum;
import com.cg.metlife.automation.Enums.CoverageheaderEnum;
import com.cg.metlife.automation.Enums.DESCobranzaEnum;
import com.cg.metlife.automation.Enums.DESPlanesEnum;
import com.cg.metlife.automation.Enums.DesAgentenum;
import com.cg.metlife.automation.Enums.DesCorreosenum;
import com.cg.metlife.automation.Enums.DesDireccionesenum;
import com.cg.metlife.automation.Enums.DesSolicitudesenum;
import com.cg.metlife.automation.Enums.DesTableEnum;
import com.cg.metlife.automation.Enums.EnumForInput;
import com.cg.metlife.automation.Enums.VdevcoverageEnum;
import com.cg.metlife.automation.model.Application;
import com.cg.metlife.automation.model.Coveragedata;
import com.cg.metlife.automation.model.DesAgent;
import com.cg.metlife.automation.model.DesCobranza;
import com.cg.metlife.automation.model.DesCorreos;
import com.cg.metlife.automation.model.DesDirecciones;
import com.cg.metlife.automation.model.DesPlanes;
import com.cg.metlife.automation.model.DesSolicitudes;
import com.cg.metlife.automation.model.VdevCoverageflag;

public class Readfile {
		static int i=0;
		static String filePath;
		
	  public static Connection getOracleConnection() throws Exception {
			  /*  String driver = "oracle.jdbc.driver.OracleDriver";
			    String url = "jdbc:oracle:thin:@10.207.180.29:1521:ORCL11";
			    String username = "seus";
			    String password = "seus";*/
		  		Connection conn= null;
		  		Properties prop = new Properties();
			    try (InputStream input = Readfile.class.getClassLoader().getResourceAsStream("application.properties")) {	            
		            prop.load(input);
		            filePath =prop.getProperty("filePath");
		            Class.forName(prop.getProperty("db.driver")); 
				    conn = DriverManager.getConnection(prop.getProperty("db.url"), prop.getProperty("db.username"), prop.getProperty("db.password"));
		        } catch (IOException ex) {
		            ex.printStackTrace();
		        }
				return conn;

		    }

		public static boolean isRowEmpty(Row row){
			if(row==null) {
				return true;
			}
	         int firstCol = row.getFirstCellNum();
	         for(int cnt = 0; cnt<4 ; cnt++){
	             Cell cell = row.getCell(firstCol+cnt);
	             if(cell!=null && cell.getCellType()!=Cell.CELL_TYPE_BLANK){
	                 return false;
	             }
	         }
	         return true;
	    }
/*
		public void insertUser(Application application) {
			Connection conn;
			try {

				conn = getOracleConnection();
				PreparedStatement zwpolanDel=conn.prepareStatement("delete from ZWNPOLAN where id=?");
				zwpolanDel.setString(1, Long.toString(application.getId()));
				zwpolanDel.executeUpdate();
				
		        PreparedStatement zwpolanIns = conn.prepareStatement("INSERT INTO ZWNPOLAN VALUES (?, ?)");
		        zwpolanIns.setString(1, Long.toString(application.getId()));
		        zwpolanIns.setString(2, application.getNmpolant());
		        zwpolanIns.executeUpdate();
				
				
				PreparedStatement desAgenteDel=conn.prepareStatement("delete from DES_AGENTES where id=?");
		        PreparedStatement desAgenteIns = conn.prepareStatement("INSERT INTO DES_AGENTES VALUES (?,?,?,?,?,?)");
		        desAgenteDel.setString(1, Long.toString(application.getId()));
		        desAgenteIns.setString(1, Long.toString(application.getId()));
		        desAgenteIns.setString(2, application.getCodProducto());
		        desAgenteIns.setString(3, Long.toString(application.getId()));
		        desAgenteIns.setString(4, Character.toString(application.getDesAgent().getTIPO_AGENTE()));
		        desAgenteIns.setInt(5, application.getDesAgent().getAGENTE());
		        desAgenteIns.setString(6, application.getDesAgent().getPORCENTAJE());
		        desAgenteDel.executeUpdate();
		        desAgenteIns.executeUpdate();
				
				
		       PreparedStatement desCorreosDel=conn.prepareStatement("DELETE FROM des_correos WHERE ID=?");
		       desCorreosDel.setString(1, Long.toString(application.getId()));
		       desCorreosDel.executeUpdate();
		       
		       PreparedStatement desSolicitudesDel=conn.prepareStatement("delete from DES_SOLICITUDES where id=?");
		       desSolicitudesDel.setString(1, Long.toString(application.getId()));
		        
		       PreparedStatement desSolicitudesIns = conn.prepareStatement("INSERT INTO DES_SOLICITUDES VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		        java.util.Date utilDate = new java.util.Date();
		        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

		        desSolicitudesIns.setString(1, Long.toString(application.getId()));
		        desSolicitudesIns.setString(2, application.getCodProducto());
		        desSolicitudesIns.setString(3, Long.toString(application.getId()));
		        desSolicitudesIns.setString(4,Character.toString(application.getDesSolicitudes().getTIPO_ID()));
		        desSolicitudesIns.setInt(5, application.getDesSolicitudes().getCVE_STATUS());
		        desSolicitudesIns.setInt(6, application.getDesSolicitudes().getMONEDA());
		        desSolicitudesIns.setDate(7, sqlDate);
		        desSolicitudesIns.setDate(8, sqlDate);
		        desSolicitudesIns.setDate(9, sqlDate);
		        desSolicitudesIns.setDate(10, sqlDate);
		        desSolicitudesIns.setDate(11, null);
		        desSolicitudesIns.setDate(12, null);
		        desSolicitudesIns.setInt(13, application.getDesSolicitudes().getCVE_FORMA_PAGO());
		        desSolicitudesIns.setInt(14, 0);
		        desSolicitudesIns.setString(15,Character.toString(application.getDesSolicitudes().getMESA_GUARDIA()));
		        desSolicitudesIns.setString(16, null);
		        desSolicitudesIns.setString(17, application.getDesSolicitudes().getCVE_USUARIO());
		        desSolicitudesIns.setString(18, application.getDesSolicitudes().getPROMOTORIA());
		        desSolicitudesIns.setString(19, application.getDesSolicitudes().getZONA_PROM());
		        desSolicitudesIns.setString(20, null);
		        
		      PreparedStatement desCorreosIns = conn.prepareStatement("INSERT INTO DES_CORREOS VALUES (?,?,?,?,?,?,?)");
		      AtomicInteger seQvalueOne = new AtomicInteger(1);
		        desCorreosIns.setString(1, Long.toString(application.getId()));
		        desCorreosIns.setString(2, application.getCodProducto());
		        desCorreosIns.setString(3, Long.toString(application.getId()));
		        desCorreosIns.setString(4, application.getDesCorreos().getEMAIL());
		        desCorreosIns.setInt(5, application.getDesCorreos().getTIPO_EMAIL());

		        desCorreosIns.setInt(6, seQvalueOne.getAndIncrement());

		        desCorreosIns.setString(7, application.getDesCorreos().getEMAIL_NOTIFICAR());
		     
		        desCorreosDel.executeUpdate();
		        desSolicitudesDel.executeUpdate();
		        desSolicitudesIns.executeUpdate();
		        desCorreosIns.executeUpdate();
		        
		        
		        
		        PreparedStatement desDireccionesDel=conn.prepareStatement("DELETE FROM des_direcciones WHERE ID=?");
		        desDireccionesDel.setString(1, Long.toString(application.getId()));
		        desDireccionesDel.executeUpdate();
		        
		        PreparedStatement desDireccionesIns = conn.prepareStatement("INSERT INTO des_direcciones VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		        AtomicInteger seQvalue = new AtomicInteger(1);
		        desDireccionesIns.setString(1, String.valueOf(application.getId()));
		        desDireccionesIns.setString(2, application.getCodProducto());
		        desDireccionesIns.setString(3, String.valueOf(application.getId()));
		        desDireccionesIns.setString(4, application.getCodPlan());
		        desDireccionesIns.setInt(5, seQvalue.getAndIncrement());
		        desDireccionesIns.setString(6, String.valueOf(application.getDesDirecciones().getTIP_DIR()));
		        desDireccionesIns.setString(7, application.getDesDirecciones().getCALLE());
		        desDireccionesIns.setString(8, null);
		        desDireccionesIns.setString(9, application.getDesDirecciones().getCOLONIA());
		        desDireccionesIns.setString(10, String.valueOf(application.getDesDirecciones().getNUMEXT()));
		        desDireccionesIns.setString(11, null);
		        desDireccionesIns.setString(12, String.valueOf(application.getDesDirecciones().getESTADO()));
		        desDireccionesIns.setString(13, null);
		        desDireccionesIns.setInt(14, 0);
		        desDireccionesIns.setString(15, null);
		        desDireccionesIns.setString(16, null);
		        desDireccionesIns.setString(17, null);
		        desDireccionesIns.executeUpdate();
		       
		      
		        
		        PreparedStatement desPlanesDel=conn.prepareStatement("DELETE FROM des_planes WHERE ID=?");
		        desPlanesDel.setString(1, Long.toString(application.getId()));
		        desPlanesDel.executeUpdate();
		        
		        PreparedStatement desPlanesIns = conn.prepareStatement("INSERT INTO des_planes VALUES (?,?,?,?,?,?,?,?,?)");
			     
		        desPlanesIns.setString(1, Long.toString(application.getId()));
		        desPlanesIns.setString(2, application.getCodProducto());
		        desPlanesIns.setString(3, Long.toString(application.getId()));
		        desPlanesIns.setString(4, application.getCodPlan());
		       
		        desPlanesIns.setString(5, null);
		        desPlanesIns.setString(6, null);
		        desPlanesIns.setString(7, null);
		        desPlanesIns.setString(8, String.valueOf(application.getDesPlanes().getAPORTACION()));
		        desPlanesIns.setString(9, null);
		        desPlanesIns.executeUpdate();
		        
		        PreparedStatement desCobranzaDel=conn.prepareStatement("DELETE FROM des_cobranza WHERE ID=?");
		        desCobranzaDel.setString(1, Long.toString(application.getId()));
		        desCobranzaDel.executeUpdate();
		        
		        
		        PreparedStatement desCobranzaIns = conn.prepareStatement("INSERT INTO des_cobranza VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			     
		        desCobranzaIns.setString(1, String.valueOf(application.getId()));
		        desCobranzaIns.setString(2, application.getCodProducto());
		        desCobranzaIns.setString(3, String.valueOf(application.getId()));
		        desCobranzaIns.setInt(4, application.getDesCobranza().getRETENEDOR());
		        desCobranzaIns.setInt(5, application.getDesCobranza().getUNIDADPGO());
		        desCobranzaIns.setInt(6, application.getDesCobranza().getCONCEPTO());
		        desCobranzaIns.setString(7, String.valueOf(application.getDesCobranza().getCONDUCTO_COBRO()));
		        desCobranzaIns.setString(8, String.valueOf(application.getDesCobranza().getID_NOMINAL()));
		        desCobranzaIns.setString(9, null);
		        desCobranzaIns.setString(10, null);
		        desCobranzaIns.setString(11, null);
		        desCobranzaIns.setInt(12, application.getDesCobranza().getENT_FED());
		        desCobranzaIns.setString(13, application.getDesCobranza().getLABOR_REGIME());
		        desCobranzaIns.setString(14, application.getDesCobranza().getADSCRIPCION());
		        desCobranzaIns.setInt(15, application.getDesCobranza().getRETENEDOR_CT());
		        desCobranzaIns.setInt(16, application.getDesCobranza().getUNIDADPGO_CT());
		        
		        desCobranzaIns.executeUpdate();
		        
		        
		        
		        PreparedStatement desCoberturasDel=conn.prepareStatement("DELETE FROM des_coberturas WHERE ID=?");
		        desCoberturasDel.setString(1, Long.toString(application.getId()));
		        desCoberturasDel.executeUpdate();
		        
		        PreparedStatement desCoberturasIns = conn.prepareStatement("INSERT INTO des_coberturas VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		        if(application.getCovData()!=null) {
		        	for (Iterator it = application.getCovData().iterator(); it.hasNext(); ) {
		                Coveragedata f = (Coveragedata) it.next();
		               
		                desCoberturasIns.setString(1, String.valueOf(application.getId()));
		                desCoberturasIns.setString(2, application.getCodProducto());
		                desCoberturasIns.setString(3, String.valueOf(application.getId()));
				        desCoberturasIns.setString(4, application.getCodPlan());
				        desCoberturasIns.setString(5, f.getCOD_COBERTURA());
				        desCoberturasIns.setDouble(6, f.getSUMA_ASEGURADA());
				        desCoberturasIns.setString(7, String.valueOf(f.getDICTAMEN_MEDICO()));
				        desCoberturasIns.setString(8, String.valueOf(f.getDICTAMEN_OCUPACIONAL()));
				        desCoberturasIns.setDouble(9, f.getPRIMA());
				        desCoberturasIns.setDouble(10, f.getEXTRAPRIMA_MEDICA());
				        desCoberturasIns.setDouble(11, f.getEXTRAPRIMA_OCUPACIONAL());
				        desCoberturasIns.setString(12, f.getBENEFICIARIOS());
				        desCoberturasIns.setString(13, f.getBENEF_COMMENTS());
				        desCoberturasIns.setInt(14, f.getTERM_COB());
				        desCoberturasIns.setInt(15, f.getTIPO_LIQUIDATION());
				        desCoberturasIns.setInt(16, f.getTIPO_PAQUETE());
				        
				        desCoberturasIns.executeUpdate();
				              	            
		        } 	
		        }
		        
		        PreparedStatement desPersonasDel=conn.prepareStatement("DELETE FROM DES_PERSONAS WHERE ID=?");
		        desPersonasDel.setString(1, Long.toString(application.getId()));
		        desPersonasDel.executeUpdate();
		        PreparedStatement desPersonasIns = conn.prepareStatement("INSERT INTO DES_PERSONAS VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		        AtomicInteger seQvalueTwo = new AtomicInteger(1);
		        if(application.getCovData()!=null) {
		        	for (Iterator it = application.getCovData().iterator(); it.hasNext(); ) {
		                Coveragedata f = (Coveragedata) it.next();
		                java.sql.Date fecDate=null;
		                
		                if(f.getFEC_NACIMIENTO()==null) {
		                	fecDate=null;
		                }else { 
		                	
		                     fecDate = new java.sql.Date(f.getFEC_NACIMIENTO().getTime());
		                
		                }
		               
		                desPersonasIns.setString(1, String.valueOf(application.getId()));
		                desPersonasIns.setString(2, application.getCodProducto());
		                desPersonasIns.setString(3, String.valueOf(application.getId()));
		                desPersonasIns.setString(4, application.getCodPlan());
		                desPersonasIns.setDouble(5, seQvalueTwo.getAndIncrement());
		                desPersonasIns.setDouble(6, f.getCOD_ROL());
		                desPersonasIns.setString(7, f.getRFC());
		                desPersonasIns.setString(8, f.getCURP());
		                desPersonasIns.setString(9, f.getAP_PATERNO());
		                desPersonasIns.setString(10, f.getAP_MATERNO());
		                desPersonasIns.setString(11, f.getNOMBRE());
		                desPersonasIns.setDate(12, fecDate);
		                desPersonasIns.setString(13, f.getLUGAR_NAC());
		                desPersonasIns.setString(14, f.getCVE_SEXO());
		                desPersonasIns.setString(15, f.getEDO_CIVIL());
		                desPersonasIns.setString(16, f.getCVE_FUMADOR());
		                desPersonasIns.setDouble(17, f.getSUELDO_MENSUAL());
		                desPersonasIns.setString(18, f.getOCUPACION());
		                desPersonasIns.setString(19, f.getDET_OCUPACION());
		                desPersonasIns.setString(20, f.getMOVIL());
		                desPersonasIns.setString(21, String.valueOf(f.getMEDIO_CNT()));
		                desPersonasIns.setString(22, String.valueOf(f.getDIA_CNT()));
		                desPersonasIns.setString(23, String.valueOf(f.getHORARIO_CNT()));	        
		                desPersonasIns.executeUpdate();	
            
		        } 	
		        }

		        conn.commit();
        
		        
			} catch (Exception e) {
				System.out.println(e.toString());
				e.printStackTrace();
			}
		    
	
		}*/
		
		public static void main(String[] args) 
	    {
			
			
			Readfile readfile=new Readfile();
	    	Application appInfo=new Application();
	    	DesAgent desAgent=new DesAgent();
	    	DesCorreos desCorreos=new DesCorreos();
	    	DesDirecciones desDirecciones=new DesDirecciones();
	    	DesPlanes desPlanes=new DesPlanes();
	    	DesSolicitudes desSolicitudes= new DesSolicitudes();
	    	DesCobranza desCobranza=new DesCobranza();
	    	VdevCoverageflag vdevCoverageFlag=new VdevCoverageflag();
	    	
	        try(InputStream input = Readfile.class.getClassLoader().getResourceAsStream("application.properties"))
	        {
	        	Properties prop = new Properties();
	        	prop.load(input);
	            FileInputStream file = new FileInputStream(new File(prop.getProperty("filePath")));
	           
	            XSSFWorkbook workbook = new XSSFWorkbook(file);

	            XSSFSheet sheet = workbook.getSheetAt(0);

	            DataFormatter formatter = new DataFormatter();
	            int CounterEn=0;
	            
	            for(i=sheet.getFirstRowNum();i<=sheet.getLastRowNum();i++) { 

	        	   if(isRowEmpty(sheet.getRow(i))==false) {  
	            	String rowValue = formatter.formatCellValue(sheet.getRow(i).getCell(0));
	            	String tableEnum=DesTableEnum.values()[CounterEn].toString();
	            	switch(tableEnum) {
        			case "ZWNPOLAN":
        				desCommonRead(sheet, formatter, rowValue, tableEnum);
	            	}
	            	
	            	
	            	
	            	
	            	/*String ch=DesTableEnum.values()[CounterEn].toString();
	            		switch(ch) {
	            			case "ID":	
	            						if(ch.equals(valuee))
	            						{
	            							Long id=Long.parseLong(value);
	            							appInfo.setId(id);
	            							CounterEn++;
	            						}
	            						
	            						break;
	            			case "NMPOLANT":
	            						if(ch.equals(valuee))
	            						{
	            							appInfo.setNmpolant(value);
	            							CounterEn++;
	            						}
	            						
	            						break;
	            			case "COD_PRODUCTO":
	            						if(ch.equals(valuee))
	            						{
	            							appInfo.setCodProducto(value);
	            							CounterEn++;
	            						}
	            						
	            						break;
	            			case "COD_PLAN":
	            						if(ch.equals(valuee))
	            						{
	            							appInfo.setCodPlan(value);
	            							CounterEn++;
	            						}
	            						
	            						
	            						break;*/
	            			/*case "DES_AGENTES":
							CounterEn = caseDesAgents(appInfo, desAgent, sheet, formatter, CounterEn, valuee, ch);

	            								break;
	            	
	            			case "DES_CORREOS":
							CounterEn = caseDesCorreos(appInfo, desCorreos, sheet, formatter, CounterEn, valuee, ch);
	            								break;

	            			case "DES_DIRECCIONES":
							CounterEn = caseDesDirecciones(appInfo, desDirecciones, sheet, formatter, CounterEn, valuee,
									ch);
	            								break;
						
	            			case "DES_PLANES":	
							CounterEn = caseDesPlanes(appInfo, desPlanes, sheet, formatter, CounterEn, valuee, ch);
	            								break;
	            
	            		    case "DES_SOLICITUDES":
							CounterEn = caseDesSolicitudes(appInfo, desSolicitudes, sheet, formatter, CounterEn, valuee,
									ch);
	            								break;
	            	
	            			case "DES_COBRANZA":
							CounterEn = caseDesCobranza(appInfo, desCobranza, sheet, formatter, CounterEn, valuee, ch);
	            								break;	
	            								
	            			case "VDEV_Coverage_Flag":
	            				
							CounterEn = caseVdevCoverageFlag(appInfo, vdevCoverageFlag, sheet, formatter, CounterEn,
									valuee, ch);
	            								break;
	            	
	            	
	            			case "COVERAGE_DATA":	
							caseCoverageData(appInfo, sheet, formatter, valuee, ch);
	            									break;

	            			default:
	            						System.out.println("Thank!!");
	            						break;*/
	            		}	            	
	        	   }
//	        	   else
//	        	   {
//	        		   System.out.println("OOPs..Row is empty!!");
//	        		  
//	        	   }
	        } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	          System.out.println(appInfo.toString());
	         
	          
	         // readfile.insertUser(appInfo);
	          //Appfinal.Main(appInfo);
	         // file.close();
	        }

private static void desCommonRead(XSSFSheet sheet, DataFormatter formatter, String rowValue, String tableEnum) {
	if(rowValue.equalsIgnoreCase(tableEnum)) {
		i=i+2;
		HashMap<Integer, String> rowValues=new HashMap<Integer, String>();
		HashMap<Integer, HashMap<Integer, String>> finalKeyValuePair=new HashMap<Integer, HashMap<Integer, String>>();
		while(isRowEmpty(sheet.getRow(i))==false) {
			AtomicInteger atomicInteger = new AtomicInteger();
			short length=sheet.getRow(i).getLastCellNum();
			for(int j=0;j<length;j++) {
				Integer number=atomicInteger.getAndIncrement();
			String tableValue = formatter.formatCellValue(sheet.getRow(i).getCell(j));
			rowValues.put(number, tableValue);
			}
			finalKeyValuePair.put(atomicInteger.getAndIncrement(), rowValues);
			System.out.println(rowValues);
			//System.out.println(finalKeyValuePair);
			i++;
		}
		//finalKeyValuePair.put(rowValues.get(0), rowValues.get(1));
        	}
}
	       
  
	    

		private static int caseDesAgents(Application appInfo, DesAgent desAgent, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
				int count=0;
				int k=i+1;
				HashMap<String, String> newEntries=new HashMap<String,String>();
				while(isRowEmpty(sheet.getRow(k))==false) {
				String valAgent = formatter.formatCellValue(sheet.getRow(k).getCell(1));
				String valAgentP = formatter.formatCellValue(sheet.getRow(k).getCell(0));
				String chOne=DesAgentenum.values()[count].toString();
			
					if(chOne.equals(valAgentP)) {
					switch(chOne) {
							case "TIPO_AGENTE":
												char[] stringToCharArray = valAgent.toCharArray();
												for (char output : stringToCharArray)
													{	            			
													desAgent.setTIPO_AGENTE(output);
			    									}
												k++;
												count++;
												break;
							case "AGENTE":
												int agente=Integer.parseInt(valAgent);
												desAgent.setAGENTE(agente);
												k++;
												count++;
												break;
       		
							case "PORCENTAJE":
												desAgent.setPORCENTAJE(valAgent);
												k++;
												break;
       		
							default:
												System.out.println("");
												break;
									}
					
					
					}else {
						
						
						newEntries.put(valAgentP, valAgent);
						
						k++;
					}
					}
				desAgent.setNewEntries(newEntries);
				appInfo.setDesAgent(desAgent);
				CounterEn++;
        	
				i=k;
				
			}
			return CounterEn;
		}

		private static int caseDesCorreos(Application appInfo, DesCorreos desCorreos, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
			int count=0;
			int CO=i+1;
			HashMap<String, String> newEntries=new HashMap<String,String>();
			
			while(isRowEmpty(sheet.getRow(CO))==false) {
				String valAgentOne = formatter.formatCellValue(sheet.getRow(CO).getCell(1));
				String valAgentP = formatter.formatCellValue(sheet.getRow(CO).getCell(0));
				String chOne=DesCorreosenum.values()[count].toString();
				if(chOne.equals(valAgentP)) {
				switch(chOne)
				{
					case "EMAIL":
								desCorreos.setEMAIL(valAgentOne);
								CO++;
								count++;
								break;
					case "TIPO_EMAIL":
								int tipoEmail=Integer.parseInt(valAgentOne);
								desCorreos.setTIPO_EMAIL(tipoEmail);
								CO++;
								count++;
								break;
       		
					case "SEQ":
								int seq=Integer.parseInt(valAgentOne);
								desCorreos.setSEQ(seq);
								CO++;
								count++;
								break;
					case "EMAIL_NOTIFICAR":
								desCorreos.setEMAIL_NOTIFICAR(valAgentOne);
								CO++;
								break;
       		
					default:
								System.out.println("");
								break;
				}
			}else {
				
				
				newEntries.put(valAgentP, valAgentOne);
				
				CO++;
			}
			}
			desCorreos.setNewEntries(newEntries);
			appInfo.setDesCorreos(desCorreos);
			CounterEn++;
        	
			i=CO;	 
			}
			return CounterEn;
		}

		private static int caseDesDirecciones(Application appInfo, DesDirecciones desDirecciones, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
			int countOne=0;
			int CO1=i+1;
			
			HashMap<String, String> newEntries=new HashMap<String,String>();
			
			while(isRowEmpty(sheet.getRow(CO1))==false) {
				String valAgentTwo = formatter.formatCellValue(sheet.getRow(CO1).getCell(1));
				String chOne=DesDireccionesenum.values()[countOne].toString();
				String valAgentP = formatter.formatCellValue(sheet.getRow(CO1).getCell(0));
				
				if(chOne.equals(valAgentP)) {
				switch(chOne)
				{
						case "SEQ":
									int seq=Integer.parseInt(valAgentTwo);
									desDirecciones.setSEQ(seq);
									CO1++;
									countOne++;
									break;
						case "TIP_DIR":
									int tipDIR=Integer.parseInt(valAgentTwo);
									desDirecciones.setTIP_DIR(tipDIR);
									CO1++;
									countOne++;
									break;
       		
						case "CALLE":
									desDirecciones.setCALLE(valAgentTwo);
									CO1++;
									countOne++;
									break;
						case "COLONIA":
									desDirecciones.setCOLONIA(valAgentTwo);
									CO1++;
									countOne++;
									break;
						case "NUM_EXT":
									int NUMEXT=Integer.parseInt(valAgentTwo);
									desDirecciones.setNUMEXT(NUMEXT);
									CO1++;
									countOne++;
									break;
						case "ESTADO":
									int ESTADO=Integer.parseInt(valAgentTwo);
									desDirecciones.setESTADO(ESTADO);
									CO1++;
									countOne++;
									break;
       		
						default:
									System.out.println("");
									break;
					}
			}else {
				
				
				newEntries.put(valAgentP, valAgentTwo);
				
				CO1++;
			}
			}
			desDirecciones.setNewEntries(newEntries);
			appInfo.setDesDirecciones(desDirecciones);
			CounterEn++;
        	
			i=CO1;	 
			}
			return CounterEn;
		}

		private static int caseDesPlanes(Application appInfo, DesPlanes desPlanes, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
			int countTwo=0;
			int CO2=i+1;
			HashMap<String, String> newEntries=new HashMap<String,String>();
			
			while(isRowEmpty(sheet.getRow(CO2))==false) {
				
				String valAgentP = formatter.formatCellValue(sheet.getRow(CO2).getCell(0));
				String valAgentThree = formatter.formatCellValue(sheet.getRow(CO2).getCell(1));
				String chTwo=DESPlanesEnum.values()[countTwo].toString();
				if(chTwo.equals(valAgentP)) {
				switch(chTwo)
				{
						case "APORTACION":
											int APORTACION=Integer.parseInt(valAgentThree);
											desPlanes.setAPORTACION(APORTACION);
											CO2++;
											
											countTwo++;
											break;
        	
       		
						default:
										System.out.println("");
										break;
				}
			}
			else {
				
				
				newEntries.put(valAgentP, valAgentThree);
				
				CO2++;
			}
			}
			desPlanes.setNewEntries(newEntries);
			appInfo.setDesPlanes(desPlanes);
			CounterEn++;
        	
			i=CO2;	 
			}
			return CounterEn;
		}

		private static int caseDesSolicitudes(Application appInfo, DesSolicitudes desSolicitudes, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
			int countThree=0;
			int CO3=i+1;
        	
			HashMap<String, String> newEntries=new HashMap<String,String>();
			
			while(isRowEmpty(sheet.getRow(CO3))==false)
			{
				String valAgentP = formatter.formatCellValue(sheet.getRow(CO3).getCell(0));
				String valAgentFour = formatter.formatCellValue(sheet.getRow(CO3).getCell(1));
				String chThree=DesSolicitudesenum.values()[countThree].toString();
				if(chThree.equals(valAgentP)) {
					switch(chThree) {
										case "TIPO_ID":
       		
														char[] stringToCharArrayOne = valAgentFour.toCharArray();
														for (char outputOne : stringToCharArrayOne)
														{	            			
															desSolicitudes.setTIPO_ID(outputOne);
       		
														}
														CO3++;
														countThree++;
														break;
										case "CVE_STATUS":
														int cveStatus=Integer.parseInt(valAgentFour);
														desSolicitudes.setCVE_STATUS(cveStatus);
														CO3++;
														countThree++;
														break;
       		
										case "MONEDA":
														int MONEDA=Integer.parseInt(valAgentFour);
														desSolicitudes.setMONEDA(MONEDA);
														CO3++;
														countThree++;
														break;
       		
										case "CVE_FORMA_PAGO":
														int cveFormaPago=Integer.parseInt(valAgentFour);
														desSolicitudes.setCVE_FORMA_PAGO(cveFormaPago);
														CO3++;
														countThree++;
														break;
										case "MESA_GUARDIA":
       		
														char[] stringToCharArrayTwo = valAgentFour.toCharArray();
														for (char outputTwo : stringToCharArrayTwo)
														{	            			
															desSolicitudes.setMESA_GUARDIA(outputTwo);
       		
														}
														CO3++;
														countThree++;
														break;
       		
										case "CVE_USUARIO":
       		
														desSolicitudes.setCVE_USUARIO(valAgentFour);
														CO3++;
														countThree++;
														break;
										case "PROMOTORIA":
       		
														desSolicitudes.setPROMOTORIA(valAgentFour);
														CO3++;
														countThree++;
														break;
										case "ZONA_PROM":
       		
														desSolicitudes.setZONA_PROM(valAgentFour);
														CO3++;
														countThree++;
														break;
       		
										default:
														System.out.println("");
														break;
						}
			}else {
				
				
				newEntries.put(valAgentP, valAgentFour);
				
				CO3++;
			}
			}
			desSolicitudes.setNewEntries(newEntries);
			appInfo.setDesSolicitudes(desSolicitudes);
			CounterEn++;
        	
			i=CO3;	 
			}
			return CounterEn;
		}

		private static int caseVdevCoverageFlag(Application appInfo, VdevCoverageflag vdevCoverageFlag, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
				int countFive=0;
				int CO6=i+1;
				HashMap<String, String> newEntries=new HashMap<String,String>();
				
				
				while(isRowEmpty(sheet.getRow(CO6))==false)
				{
					
					String valAgentP = formatter.formatCellValue(sheet.getRow(CO6).getCell(0));
					String valAgentSix = formatter.formatCellValue(sheet.getRow(CO6).getCell(1));
					String chFive=VdevcoverageEnum.values()[countFive].toString();
					
					if(chFive.equals(valAgentP)) {
					switch(chFive)
					{
					case "VDEVRequired":
										char[] stringToCharArrayThree = valAgentSix.toCharArray();
										for (char outputThree : stringToCharArrayThree)
										{	
      			
											vdevCoverageFlag.setVDEVRequired(outputThree);
       		
										}
										CO6++;
										countFive++;
										break;
        	
       		
					default:
										System.out.println("");
										break;
				}
			}else {
				
				
				newEntries.put(valAgentP, valAgentSix);
				
				CO6++;
			}
			}
				vdevCoverageFlag.setNewEntries(newEntries);
			appInfo.setVedevCoverageFlag(vdevCoverageFlag);
			CounterEn++;
        	
			i=CO6;	 
       		}
			return CounterEn;
		}

		private static int caseDesCobranza(Application appInfo, DesCobranza desCobranza, HSSFSheet sheet,
				DataFormatter formatter, int CounterEn, String valuee, String ch) {
			if(ch.equals(valuee))
			{
			int countFour=0;
			int CO4=i+1;
        	
			HashMap<String, String> newEntries=new HashMap<String,String>();
			
			while(isRowEmpty(sheet.getRow(CO4))==false)
			{
				String valAgentP = formatter.formatCellValue(sheet.getRow(CO4).getCell(0));
				String valAgentFive = formatter.formatCellValue(sheet.getRow(CO4).getCell(1));
				String chFour=DESCobranzaEnum.values()[countFour].toString();
				if(chFour.equals(valAgentP)) {
				switch(chFour)
				{
					case "RETENEDOR":
										int RETENEDOR=Integer.parseInt(valAgentFive);
										desCobranza.setRETENEDOR(RETENEDOR);
										CO4++;
										countFour++;
										break;
					case "UNIDADPGO":
										int UNIDADPGO=Integer.parseInt(valAgentFive);
										desCobranza.setUNIDADPGO(UNIDADPGO);
										CO4++;
										countFour++;
										break;
       		
					case "CONCEPTO":
										int CONCEPTO=Integer.parseInt(valAgentFive);
										desCobranza.setCONCEPTO(CONCEPTO);
										CO4++;
										countFour++;
										break;
       		
					case "CONDUCTO_COBRO":
										int conductoCOBRO=Integer.parseInt(valAgentFive);
										desCobranza.setCONDUCTO_COBRO(conductoCOBRO);
										CO4++;
										countFour++;
										break;
					case "ID_NOMINAL":
										BigInteger idNominal=new BigInteger(valAgentFive);
										desCobranza.setID_NOMINAL(idNominal);
										CO4++;
										countFour++;
										break;
					case "NUM_CUENTA":
       		
										desCobranza.setNUM_CUENTA(valAgentFive);
										CO4++;
										countFour++;
										break;
					case "CLAVE_BANCO":
       		
										desCobranza.setCLAVE_BANCO(valAgentFive);
										CO4++;
										countFour++;
										break;
					case "SUCURSAL":
       		
										desCobranza.setSUCURSAL(valAgentFive);
										CO4++;
										countFour++;
										break;
					case "ENT_FED":
										int entFed=Integer.parseInt(valAgentFive);
										desCobranza.setENT_FED(entFed);
										CO4++;
										countFour++;
										break;
					case "LABOR_REGIME":
										desCobranza.setLABOR_REGIME(valAgentFive);
										CO4++;
										countFour++;
										break;
					case "ADSCRIPCION":
										desCobranza.setADSCRIPCION(valAgentFive);
										CO4++;
										countFour++;
										break;
					case "RETENEDOR_CT":
										int retendorCt=Integer.parseInt(valAgentFive);
										desCobranza.setRETENEDOR_CT(retendorCt);
										CO4++;
										countFour++;
										break;
					case "UNIDADPGO_CT":
										int unidaapgoCt=Integer.parseInt(valAgentFive);
										desCobranza.setUNIDADPGO_CT(unidaapgoCt);
										CO4++;
										countFour++;
										break;
       		
       		
					default:
										System.out.println("");
										break;
				}
			}else {
				
				
				newEntries.put(valAgentP, valAgentFive);
				
				CO4++;
			}
			}
			appInfo.setDesCobranza(desCobranza);
			CounterEn++;
        	
			i=CO4;	 
			}
			return CounterEn;
		}

		private static void caseCoverageData(Application appInfo, HSSFSheet sheet, DataFormatter formatter,
				String valuee, String ch) {
			Coveragedata covData;
			if(ch.equals(valuee))
			{
				int CO7=i+2;
				
				HashMap<String, HashMap<CoverageheaderEnum, String>> hashMapOfAllRows = new HashMap<String, HashMap<CoverageheaderEnum, String>>();
				HashMap<String, HashMap<CoverageheaderEnum, String>> compare=new HashMap<String,HashMap<CoverageheaderEnum, String>>(); 
				int countForEnum=0;
				
				
				while(CO7 <= sheet.getLastRowNum())
				
				{
					 Row row1= sheet.getRow(CO7);
					 String chFive=Coverageenum.values()[countForEnum].toString();
					
					 short length = row1.getLastCellNum();
					
					 HashMap<CoverageheaderEnum, String> rowObject = new HashMap<CoverageheaderEnum, String> ();
						for (int J = 0; J < length; J++)
							{
									try {
										
									   if(isCellDateFormatted(row1.getCell(J)))
									   {
											rowObject.put(CoverageheaderEnum.values()[J],  format("dd/MM/yyyy",row1.getCell(J).getDateCellValue()));
									   }
									  else {
										  rowObject.put(CoverageheaderEnum.values()[J], formatter.formatCellValue(row1.getCell(J)));}

									}catch (Exception e) {
										e.printStackTrace();
									}
								  			     												
							}
						hashMapOfAllRows.put(chFive, rowObject);
						
						if((rowObject.get(CoverageheaderEnum.values()[0]).equalsIgnoreCase("y")))
						{
						compare.put(chFive,rowObject);
						}
						
						countForEnum++;
						CO7++;
				} 
				
				
				Set<Coveragedata> coverage=new HashSet<>();
				
				for (Map.Entry<String, HashMap<CoverageheaderEnum, String>> entry : compare.entrySet())
				{ 
					covData =new Coveragedata();
					covData.setCOVERAGE_CONSIDERATION_FLG(entry.getValue().get(CoverageheaderEnum.COVERAGE_CONSIDERATION_FLG));
					covData.setCOD_COBERTURA(entry.getValue().get(CoverageheaderEnum.COD_COBERTURA));
					
					String SUMA_ASEGURADA=entry.getValue().get(CoverageheaderEnum.SUMA_ASEGURADA);
					covData.setSUMA_ASEGURADA(Double.parseDouble(SUMA_ASEGURADA));
					
					String DICTAMEN_MEDICO=entry.getValue().get(CoverageheaderEnum.DICTAMEN_MEDICO);
					covData.setDICTAMEN_MEDICO(Integer.parseInt(DICTAMEN_MEDICO));
					
					String DICTAMEN_OCUPACIONAL=entry.getValue().get(CoverageheaderEnum.DICTAMEN_OCUPACIONAL);
					covData.setDICTAMEN_OCUPACIONAL(Integer.parseInt(DICTAMEN_OCUPACIONAL));
					
					String PRIMA=entry.getValue().get(CoverageheaderEnum.PRIMA);
					covData.setPRIMA(Double.parseDouble(PRIMA));
					
					String EXTRAPRIMA_MEDICA=entry.getValue().get(CoverageheaderEnum.EXTRAPRIMA_MEDICA);
					int extMedica=(int)Double.parseDouble(EXTRAPRIMA_MEDICA);
					covData.setEXTRAPRIMA_MEDICA(extMedica);
					
					String EXTRAPRIMA_OCUPACIONAL=entry.getValue().get(CoverageheaderEnum.EXTRAPRIMA_OCUPACIONAL);
					int ext=(int)Double.parseDouble(EXTRAPRIMA_OCUPACIONAL);
					covData.setEXTRAPRIMA_OCUPACIONAL(ext);
					
					covData.setBENEFICIARIOS(entry.getValue().get(CoverageheaderEnum.BENEFICIARIOS));
					
					covData.setBENEF_COMMENTS(entry.getValue().get(CoverageheaderEnum.BENEF_COMMENTS));
					
					String TERM_COB=entry.getValue().get(CoverageheaderEnum.TERM_COB);
					
					if(TERM_COB.equals(""))
					{								
					}
					else
					{
						covData.setTERM_COB(Integer.parseInt(TERM_COB));
					}
					
					String TIPO_LIQUIDATION=entry.getValue().get(CoverageheaderEnum.TIPO_LIQUIDATION);
					if(TIPO_LIQUIDATION.equals(""))
					{		
					}
					else
					{
						covData.setTIPO_LIQUIDATION(Integer.parseInt(TIPO_LIQUIDATION));				
					}
			
					String TIPO_PAQUETE=entry.getValue().get(CoverageheaderEnum.TIPO_PAQUETE);
					
					if(TIPO_PAQUETE.equals(""))
					{	
					}
					else {
						covData.setTIPO_PAQUETE(Integer.parseInt(TIPO_PAQUETE));		
					}
					
					String COD_ROL=entry.getValue().get(CoverageheaderEnum.COD_ROL);
					
					if(COD_ROL.equals(""))
					{		
					}
					else {
						covData.setCOD_ROL(Integer.parseInt(COD_ROL));	
					}
			
					covData.setRFC(entry.getValue().get(CoverageheaderEnum.RFC));
					covData.setCURP(entry.getValue().get(CoverageheaderEnum.CURP));
					covData.setAP_PATERNO(entry.getValue().get(CoverageheaderEnum.AP_PATERNO));
					covData.setAP_MATERNO(entry.getValue().get(CoverageheaderEnum.AP_MATERNO));
					covData.setNOMBRE(entry.getValue().get(CoverageheaderEnum.NOMBRE));
					
					String FEC_NACIMIENTO=entry.getValue().get(CoverageheaderEnum.FEC_NACIMIENTO);
					if(FEC_NACIMIENTO != null && !FEC_NACIMIENTO.equals("")) 
					{
						covData.setFEC_NACIMIENTO(parse("dd/MM/yyyy",FEC_NACIMIENTO));
					}
					else {
						// to do
					}
        	
					
					
					covData.setLUGAR_NAC(entry.getValue().get(CoverageheaderEnum.LUGAR_NAC));
					covData.setCVE_SEXO(entry.getValue().get(CoverageheaderEnum.CVE_SEXO));
					covData.setEDO_CIVIL(entry.getValue().get(CoverageheaderEnum.CVE_SEXO));
					covData.setEDO_CIVIL(entry.getValue().get(CoverageheaderEnum.EDO_CIVIL));
					covData.setCVE_FUMADOR(entry.getValue().get(CoverageheaderEnum.CVE_FUMADOR));
					
					String SUELDO_MENSUAL=entry.getValue().get(CoverageheaderEnum.SUELDO_MENSUAL);
					if(SUELDO_MENSUAL.equals(""))
					{
						
					}else{
					covData.setSUELDO_MENSUAL(Double.parseDouble(SUELDO_MENSUAL));
					}
					
					
					
					covData.setOCUPACION(entry.getValue().get(CoverageheaderEnum.OCUPACION));
					
					covData.setDET_OCUPACION(entry.getValue().get(CoverageheaderEnum.DET_OCUPACION));
					covData.setMOVIL(entry.getValue().get(CoverageheaderEnum.MOVIL));
					String MEDIO_CNT=entry.getValue().get(CoverageheaderEnum.MEDIO_CNT);
					if(MEDIO_CNT.equals(""))
					{
						
					}
					else{
					covData.setMEDIO_CNT(Integer.parseInt(MEDIO_CNT));
					}
					
					String DIA_CNT=entry.getValue().get(CoverageheaderEnum.DIA_CNT);
					if(DIA_CNT.equals(""))
					{
						
					}
					else{
					covData.setDIA_CNT(Integer.parseInt(DIA_CNT));
					}
					
					
					String HORARIO_CNT=entry.getValue().get(CoverageheaderEnum.HORARIO_CNT);
					if(HORARIO_CNT.equals("")) {
						
					}else{
					covData.setHORARIO_CNT(Integer.parseInt(HORARIO_CNT));
					}
					
				coverage.add(covData);
					}
				
				
				appInfo.setCovData(coverage);           									
				
				i=CO7;
			}
		}
		
		
		
		private static Date parse(String pattern,String dateString) {
			if(dateString == null || dateString.isEmpty()) return null;

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			Date date = null;
			try {
				date = simpleDateFormat.parse(dateString);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			return date;
		}
		
		private static String format(String pattern,Date date) {
			if(date == null) return null;

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			return simpleDateFormat.format(date);
		}
		
		
			
public static boolean isCellDateFormatted(Cell cell) {
    if (cell == null) return false;
    boolean bDate = false;
        CellStyle style = cell.getCellStyle();
        if(style==null) return false;
        int i = style.getDataFormat();
        String f = style.getDataFormatString();
        bDate = DateUtil.isADateFormat(i, f);
    return bDate;
}					
}			
			
			
			
			
			
			
	


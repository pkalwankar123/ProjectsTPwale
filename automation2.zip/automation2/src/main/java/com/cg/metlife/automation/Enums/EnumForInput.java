package com.cg.metlife.automation.Enums;

public enum EnumForInput {

		ID,
		NMPOLANT, 
		COD_PRODUCTO, 
		COD_PLAN, 
		DES_AGENTES, 
		DES_CORREOS,
		DES_DIRECCIONES,
		DES_PLANES,
		DES_SOLICITUDES,
		DES_COBRANZA,
		VDEV_Coverage_Flag,
		COVERAGE_DATA
				
}

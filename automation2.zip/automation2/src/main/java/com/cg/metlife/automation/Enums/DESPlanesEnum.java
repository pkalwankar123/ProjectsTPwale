package com.cg.metlife.automation.Enums;

public enum DESPlanesEnum {
	APORTACION
}

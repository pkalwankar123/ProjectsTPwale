package com.cg.metlife.automation.Enums;

public enum DESCobranzaEnum {
	RETENEDOR,
	UNIDADPGO,
	CONCEPTO,
	CONDUCTO_COBRO,
	ID_NOMINAL,
	NUM_CUENTA,
	CLAVE_BANCO,
	SUCURSAL,
	ENT_FED,
	LABOR_REGIME,
	ADSCRIPCION,
	RETENEDOR_CT,
	UNIDADPGO_CT

}

package com.cg.metlife.automation.Enums;

public enum DesDireccionesenum {
	 		SEQ,
		TIP_DIR,
		CALLE,
		COLONIA,
		 NUM_EXT,
		 ESTADO
}

package com.cg.metlife.automation.model;

import java.util.HashMap;

public class VdevCoverageflag {
private char VDEVRequired;
private HashMap<String, String> newEntries;


public char getVDEVRequired() {
	return VDEVRequired;
}

public void setVDEVRequired(char vDEVRequired) {
	VDEVRequired = vDEVRequired;
}

public HashMap<String, String> getNewEntries() {
	return newEntries;
}

public void setNewEntries(HashMap<String, String> newEntries) {
	this.newEntries = newEntries;
}

@Override
public String toString() {
	return "VDEVCoverageFlag [VDEVRequired=" + VDEVRequired + ", newEntries=" + newEntries + "]";
}




}

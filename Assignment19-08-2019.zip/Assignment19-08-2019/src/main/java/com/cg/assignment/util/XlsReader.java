/*package com.cg.assignment.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

class XlsReader 
{
	static Row row;
	static Cell cell;
	static ExecutorService executorService = Executors.newFixedThreadPool(4); 
	


	public static void main(String[] args) throws InterruptedException, IOException 
	{
		File inputFile = new File("C:\\PRADIP\\19082019\\MOII Scenarios.xlsx");
		File outputFile = new File("C:\\\\PRADIP\\\\19082019\\\\Output.csv");
		
		// For storing data into CSV files
		StringBuffer data = new StringBuffer();
		
		
		FileOutputStream fos = new FileOutputStream(outputFile);

		// Get the workbook object for XLS file
		XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(inputFile));
		// Get first sheet from the workbook
		XSSFSheet sheet = workbook.getSheetAt(0);
		//System.out.println(data.toString());
		try 
		{

		// Iterate through each rows from first sheet
		Iterator rowIterator = sheet.iterator();
		int colcount = 0;
		int rowcount = 0;
		while (rowIterator.hasNext()) 
		{
			row = (Row) rowIterator.next();
			// For each row, iterate through each columns
		
			Iterator cellIterator = row.cellIterator();
			
			
			while (cellIterator.hasNext()) 
			{
				cell = (Cell) cellIterator.next();
				//System.out.println(cell.getColumnIndex());
				//System.out.println(cell);
				//if(cell.getColumnIndex()==1) {
				//break;
				//}
				
				Runnable task1 = () -> {
			        System.out.println("Executing Task1 inside : " + Thread.currentThread().getName());
			        //TimeUnit.SECONDS.sleep(2);
					if(cell.getColumnIndex()==XSSFCell.CELL_TYPE_NUMERIC)
					{ 
					  //int name = (int) row.getCell(0).getNumericCellValue(); 
					  System.out.println("Pradip"); 
					  data.append(cell.getNumericCellValue() + ",");
					 
					  } 
					else {
						 System.out.println("Error"); 
					}
					
			    };
			    
				
				
				switch (cell.getCellType()) 
				{
				
				
				case Cell.CELL_TYPE_BOOLEAN:
					data.append(cell.getBooleanCellValue() + ","+"\n");
					//System.out.println();
					break;
					
				case Cell.CELL_TYPE_NUMERIC:
					data.append(cell.getNumericCellValue() + ",");
				//System.out.println("hello chavya");
					break;
					
				case Cell.CELL_TYPE_STRING:
					data.append(cell.getStringCellValue() + ",");
					//System.out.println("hello Pradip");
					break;
				
				case Cell.CELL_TYPE_BLANK:
					data.append("" + ",");
					//System.out.println();
					break;
				
				default:
					data.append(cell + ",");
				}
	                        
	                       // data.append('\t');
	                  
	            executorService.execute(task1);
	           
			}colcount++;
			 //data.append('\n');
			
			rowcount ++;
		}

		
			
		fos.write(data.toString().getBytes());
		fos.close();
		
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally {
			
			executorService.shutdown();
		}
	}
}
 */
/*package com.cg.assignment.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Simple
{
	static FileOutputStream fos =null;
	static FileOutputStream fossuccess =null; 
    public static void main(String[] args) throws IOException
    {
    	HashMap<Integer,List<Cell>> hm=new HashMap<Integer,List<Cell>>();
    	StringBuffer buffer=new StringBuffer();
    	StringBuffer buffersuccess=new StringBuffer();
    	
    	ExecutorService executorService = Executors.newSingleThreadExecutor();
    	File ferror=new File("C:\\\\PRADIP\\\\19082019\\\\MOII ScenarioError.csv");
    	File fsuccess=new File("C:\\\\PRADIP\\\\19082019\\\\MOII ScenarioSuccess.csv");
        
     
    		String regex = "^[a-zA-Z0-9]+$";
    		String regex1 = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$";
    		String regex2 = "^[a-zA-Z0-9- ]+$";
    		Pattern pattern = Pattern.compile(regex);
    		Pattern pattern1 = Pattern.compile(regex1); 
    		Pattern pattern2 = Pattern.compile(regex2); 
    		 

        
        try
        {
        	fos=new FileOutputStream(ferror);
        	fossuccess=new FileOutputStream(fsuccess);
        	  FileInputStream file = new FileInputStream(new File("C:\\\\PRADIP\\\\19082019\\\\MOII Scenarios.xlsx"));
 
            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);
 
            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheetAt(0);
            
            //Iterate through each rows one by one
            Iterator<Row> rowIterator = sheet.iterator();
            hm.put(1, new ArrayList<Cell>());
            hm.put(2, new ArrayList<Cell>());
            hm.put(3, new ArrayList<Cell>());
            hm.put(4, new ArrayList<Cell>());
            hm.put(5, new ArrayList<Cell>());
            hm.put(6, new ArrayList<Cell>());
            hm.put(7, new ArrayList<Cell>());
            hm.put(8, new ArrayList<Cell>());
            hm.put(9, new ArrayList<Cell>());
            hm.put(10, new ArrayList<Cell>());
            while (rowIterator.hasNext())
            {
            	int i=1;
                Row row = rowIterator.next();
                //For each row, iterate through all the columns
                Iterator<Cell> cellIterator = row.cellIterator();               
                while (cellIterator.hasNext())
                {
                    Cell cell = cellIterator.next();
                    hm.get(i).add(cell);
                    i++;
                 }
                System.out.println("");
            }
            file.close();
            hm.forEach((key,value) -> System.out.println(key + " = " + value));
           }
        
               catch (Exception e)
              {
                  e.printStackTrace();
              }
        
        
        
        Runnable task1 = () -> {
                                hm.get(1).forEach( name -> 
                                  {
                                   if(name.getCellType()==Cell.CELL_TYPE_NUMERIC|| hm.get(1).indexOf(name)==0) 
                                  {
                            	  buffersuccess.append(name+ ","+" ");
                            	  System.out.println(name +"  is string");
                            	  
                                  }
                                 else
                                  {  
                            	   System.out.println(name + "  is not string");
                            	   buffer.append("row "+ hm.get(1).indexOf(name)+" , column 1 , value "+name + " is not numeric \n");
                                  }
                                  }
                             );
                     
                buffersuccess.append("\n"); 
                };
      Runnable task2 = () -> {
              
                              hm.get(2).forEach( name -> 
                                 {
                                 if(name.getCellType()==Cell.CELL_TYPE_STRING) 
                                 {
                              	  buffersuccess.append(name+ ","+" ");
                              	  System.out.println(name +"  is string"); 
                                 }
                                 else
                                 {  
                              	   System.out.println(name + "  is not string");
                              	   buffer.append("row "+ hm.get(2).indexOf(name)+" , column 2 , value "+name + " is not valid \n");
                              	
                                 }
                                 }
                                 );
             
          
             buffersuccess.append("\n"); 
             };
    Runnable task3 = () -> {
                
                              hm.get(3).forEach( name -> 
                                   {
                                   if(name.getCellType()==Cell.CELL_TYPE_STRING) 
                                   {
                                	  buffersuccess.append(name+  ","+"\t");
                                	  System.out.println(name +"  is string"); 
                                   }
                                   else
                                   {  
                                	   System.out.println(name + "  is not string");
                                	   buffer.append("row "+ hm.get(3).indexOf(name)+" , column 3 , value "+name + " is not valid \n");
                                	
                                   }
                                   }
                                   );
               
               
                buffersuccess.append("\n"); 
                };
       Runnable task4 = () -> {
                          buffersuccess.append(hm.get(4).get(0)+"  ");
                                hm.get(4).forEach( name -> 
                                     {
                                       if(name.getCellType()==Cell.CELL_TYPE_STRING) 
                                         { 
                                        Matcher matcher = pattern1.matcher(name.getStringCellValue());
                                       	if(matcher.matches()==true) {
                                       		 buffersuccess.append(name.getStringCellValue()+ ","+"\t");
                                              }
                                        	 else
                                             {  
                                        		 
                                        		 buffer.append("row "+ hm.get(4).indexOf(name)+" , column 4 , value "+name + " is not date \n");
                                             }
                                           }
                                           else
                                           {  
                                        	   buffer.append("row "+ hm.get(4).indexOf(name)+" , column 4 , value "+name + " is not date \n"); 
                                           }
                                    
                                     }
                                     );
                
                 buffersuccess.append("\n"); 
                };
       Runnable task5 = () -> {
                    
                                hm.get(5).forEach( name -> 
                                       {
                                       if(name.getCellType()==(Cell.CELL_TYPE_STRING)||name.getCellType()==(Cell.CELL_TYPE_BLANK)) 
                                       {
                                    	  buffersuccess.append(name+ ","+"\t");
                                    	  System.out.println(name +"  is string"); 
                                       }
                                       else
                                       {  
                                    	   System.out.println(name + "  is not string");
                                    	   buffer.append("row "+ hm.get(5).indexOf(name)+" , column 5 , value "+name + " is not string \n");
                                    	
                                       }
                                       }
                                       );
                   
                    
                     buffersuccess.append("\n"); 
                     };
      Runnable task6 = () -> {
                                hm.get(6).forEach( name -> 
                                         {
                                        	 if(name.getCellType()==(Cell.CELL_TYPE_STRING)||name.getCellType()==(Cell.CELL_TYPE_BLANK) ) 
                                                 
                                             { 
                                       	     Matcher matcher = pattern.matcher(name.getStringCellValue());
                                          	if(matcher.matches()==true) {
                                          		 buffersuccess.append(name.getStringCellValue()+ ","+" ");
                                                	  }
                                           	 else
                                                {  
                                           		 
                                           		 buffer.append("row "+ hm.get(6).indexOf(name)+" , column 6 , value "+name + " is not date \n");
                                            	  // hm.get(1).remove(name);
                                                }
                                          
                                           	 
                                              }
                                              else
                                              {  
                                           	   buffer.append("row "+ hm.get(6).indexOf(name)+" , column 6 , value "+name + " is not date \n"); 
                                              }
                                       
                                         }
                                         );
                     
                     
                     buffersuccess.append("\n"); 
                    };
      Runnable task7 = () -> {
                                         hm.get(7).forEach( name -> 
                                           {
                                        	   if(name.getCellType()==(Cell.CELL_TYPE_STRING)||name.getCellType()==(Cell.CELL_TYPE_BLANK)) 
                                                   
                                               { 
                                                Matcher matcher = pattern.matcher(name.getStringCellValue());
                                            	if(matcher.matches()==true) {
                                            		 buffersuccess.append(name.getStringCellValue()+ ","+" ");
                                                  	  }
                                             	 else
                                                  {  
                                             		 
                                             		 buffer.append("row "+ hm.get(7).indexOf(name)+" , column 7 , value "+name + " is not valid \n");
                                              	  // hm.get(1).remove(name);
                                                  }
                                            
                                             	 
                                                }
                                                else
                                                {  
                                             	   buffer.append("row "+ hm.get(7).indexOf(name)+" , column 7, value "+name + " is not valid \n"); 
                                                }
                                         
                                           }
                                           );
                       
                      
                       buffersuccess.append("\n"); 
                      };
       Runnable task8 = () -> {
                                  hm.get(8).forEach( name -> 
                                             {
                                             if(name.getCellType()==(Cell.CELL_TYPE_STRING)||name.getCellType()==(Cell.CELL_TYPE_BLANK)) 
                                             {
                                          	  buffersuccess.append(name+  ","+" ");
                                          	  System.out.println(name +"  is string"); 
                                             }
                                             else
                                             {  
                                          	   System.out.println(name + "  is not string");
                                          	   buffer.append("row "+ hm.get(8).indexOf(name)+" , column 8 , value "+name + " is not valid \n");
                                          	
                                             }
                                             }
                                             );
                         
                      
                         buffersuccess.append("\n"); 
                        };
       Runnable task9 = () -> {
                                   hm.get(9).forEach( name -> 
                                             {
                                             if(name.getCellType()==(Cell.CELL_TYPE_STRING)||name.getCellType()==(Cell.CELL_TYPE_BLANK)) 
                                             {
                                          	  buffersuccess.append(name+  ","+" ");
                                          	  System.out.println(name +"  is string"); 
                                             }
                                             else
                                             {  
                                          	   System.out.println(name + "  is not string");
                                          	   buffer.append("row "+ hm.get(9).indexOf(name)+" , column 9 , value "+name + " is not valid \n");
                                          	
                                             }
                                             }
                                             );
                         
                       
                         buffersuccess.append("\n"); 
                        };
         Runnable task10 = () -> {
                                       hm.get(10).forEach( name -> 
                                               {
                                            	   if(name.getCellType()==Cell.CELL_TYPE_STRING ) 
                                                       
                                                   { 
                                          Matcher matcher = pattern2.matcher(name.getStringCellValue());
                                                	if(matcher.matches()==true) {
                                                		 buffersuccess.append(name.getStringCellValue()+ ","+"\t");
                                                      	  }
                                                 	 else
                                                      {  
                                                 		 
                                                 		 buffer.append("row "+ hm.get(10).indexOf(name)+" , column 10 , value "+name + " is not valid \n");

                                                      }
                                                
                                                 	 
                                                    }
                                                    else
                                                    {  
                                                 	   buffer.append("row "+ hm.get(10).indexOf(name)+" , column 10 , value "+name + " is not valid \n"); 
                                                    }
                                             
                                               }
                                               );
                          
                           

                                   	 try {
										fossuccess.write(buffersuccess.toString().getBytes());
										fossuccess.close();
										fos.write(buffer.toString().getBytes());
										fos.close();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
                           			
                                       buffersuccess.append("\n"); 
                            };
                            
                            
                            
                 			
                 		   
                            
                            
                            buffersuccess.append("\n"); 
          executorService.execute(task1);
          executorService.execute(task2);
          executorService.execute(task3);
          executorService.execute(task4);
          executorService.execute(task5);
          executorService.execute(task6);
          executorService.execute(task7);
          executorService.execute(task8);
          executorService.execute(task9);
          executorService.execute(task10);
          executorService.shutdown();
         
          
          
    }
}*/
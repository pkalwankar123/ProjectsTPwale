package com.cg.assignment.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDateReader { 
	public static void main(String[] args) throws FileNotFoundException, IOException {

/*	writeIntoExcel("C:\\\\\\\\PRADIP\\\\\\\\19082019\\\\\\\\Output.csv");
	readFromExcel("C:\\\\\\\\PRADIP\\\\\\\\MOII Scenarios.xlsx");
	}

	public static void readFromExcel(String file) throws IOException{
		XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
		XSSFSheet myExcelSheet = myExcelBook.getSheet("Sheet1");
		XSSFRow row = myExcelSheet.getRow(0); 
	
	
		if(row.getCell(0).getCellType() == XSSFCell.CELL_TYPE_STRING){
			String name = row.getCell(0).getStringCellValue();
			System.out.println("name : " + name);
			}
		if(row.getCell(1).getCellType() == XSSFCell.CELL_TYPE_NUMERIC){
			//Date birthdate = row.getCell(1).getDateCellValue();
			//System.out.println("birthdate :" + birthdate);
			}
		myExcelBook.close();
		} 
	*/

	
	}
}
	



package com.cg.assignment.utila;

public enum headerEnum {
	Employee_name,
	Employee_Id,
	DOB
}

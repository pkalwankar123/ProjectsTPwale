/*package com.cg.assignment.util;

import java.awt.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class mainAssignment {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
			 int ch;
			 
			 File f=new File("C:\\\\PRADIP\\\\19082019\\\\Success.csv");
		 	File fone=new File("C:\\\\PRADIP\\\\19082019\\\\Error.csv");
		     FileInputStream file = new FileInputStream(new File("C:\\\\PRADIP\\\\19082019\\\\MOII Scenarios.xlsx"));
		     FileOutputStream fos = new FileOutputStream(f);
		     FileOutputStream fosSecond = new FileOutputStream(fone);
		     ExecutorService executorService = Executors.newSingleThreadExecutor();
		     //Create Workbook instance holding reference to .xlsx file
		     XSSFWorkbook workbook = new XSSFWorkbook(file);

		     //Get first/desired sheet from the workbook
		     XSSFSheet sheet = workbook.getSheetAt(0);
			      
		     
		     ArrayList ar=new ArrayList();
		     ArrayList ar1=new ArrayList<>();
		     HashMap<Integer, ArrayList<String>> hmp=new HashMap<Integer,ArrayList<String>>();
		     
			        FileInputStream fr=null;
			        FileOutputStream wr=null;
			        int columnind=0;
			    	StringBuffer data = new StringBuffer();
			    	StringBuffer dataone = new StringBuffer();
			    	 XSSFRow row=null;
			            Iterator ite = sheet.rowIterator();
			         try {
			            
			            while(ite.hasNext()) { 
			        	  row=(XSSFRow) ite.next();
			        	
			        	  System.out.println(row.getRowNum());
			        	 Iterator celli=row.cellIterator();
			        	while(celli.hasNext()) {
			        		XSSFCell cell =(XSSFCell)celli.next();
			        	
			        		 ar.add(cell);
			        		}
			 	         
			        		
			        		//ar1.add(ar);
			        		
			        		
			        		
			 	                   
			        		
			        		
			        		
			        		
			        		 switch (cell.getCellType()) { 
			                 case Cell.CELL_TYPE_STRING: 
			                     String c = cell.getStringCellValue();
			                     
			                     ar.add(c);
			                     break; 
			                 case Cell.CELL_TYPE_NUMERIC: 
			                     int n = (int) cell.getNumericCellValue();
			                     if(debug)System.out.print(n + "\t");
			                     InnerArray.add(String.valueOf(n));
			                     break; 
			                 case Cell.CELL_TYPE_BOOLEAN:
			                     boolean b = cell.getBooleanCellValue();
			                     if(debug)System.out.print(b + "\t");
			                     InnerArray.add(String.valueOf(b));
			                 break; 
			                 default : 
			                     } 
			                 }
			            
			           
			          for(String str:ar) { 
		        		hmp.put(row.getRowNum(), ar);
			          }
			            
			            Set<Entry<Integer, ArrayList<String>>> entires = hmp.entrySet();
			            for(Entry<Integer,ArrayList<String>> ent:entires){
			                System.out.println(ent.getKey()+" ==> "+ent.getValue());
			            }
			           
			           
			            
			            
			           // System.out.println(hmp);
			        		
			        	
			        	 
			        
			          
			          
			          
			          
			          
			          
			            
			  		fos.write(data.toString().getBytes());
			  		fos.close();
			  		fosSecond.write(dataone.toString().getBytes());
			  		fosSecond.close();
			  		
			  		}
			  		catch (FileNotFoundException e) 
			  		{
			  			e.printStackTrace();
			  		}
			  		catch (IOException e) 
			  		{
			  			e.printStackTrace();
			  		}
			  		finally {
			  			
			  			//executorService.shutdown();
			  		}
			        	 
			          }
		
		
	}


			        
*/
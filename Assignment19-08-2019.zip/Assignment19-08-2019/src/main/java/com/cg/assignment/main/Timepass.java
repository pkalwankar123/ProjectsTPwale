package com.cg.assignment.main;

public class Timepass {

	public static void main(String[] args) {
		
int a[]= {1,1,2,2,1,1,3,4};

String str=a.toString();

System.out.println(str);

/*for(int i=0;i<a.length;i++) {
	
}*/



	}

}

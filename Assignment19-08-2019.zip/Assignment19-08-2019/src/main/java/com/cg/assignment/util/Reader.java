package com.cg.assignment.util;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Reader {
 
 
 
    public static void main(String[] args) throws Exception {
 
 
 
        String filename = "C:\\\\PRADIP\\\\19082019\\\\MOII Scenarios.xlsx";
        FileInputStream fis = null;
 
        try {
 
            fis = new FileInputStream(filename);
          //  FileInputStream file = new FileInputStream(new File("C:\\PRADIP\\19082019\\MOII Scenarios.xlsx"));
            
            //Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
 
            //Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator rowIter = sheet.rowIterator(); 
 
            while(rowIter.hasNext()){
                XSSFRow myRow = (XSSFRow) rowIter.next();
                Iterator cellIter = myRow.cellIterator();
                Vector<String> cellStoreVector=new Vector<String>();
                while(cellIter.hasNext()){
                    XSSFCell myCell = (XSSFCell) cellIter.next();
                    String cellvalue = myCell.getStringCellValue();
                    cellStoreVector.addElement(cellvalue);
                }
                String firstcolumnValue = null;
                String secondcolumnValue = null;
 
                int i = 0;
                firstcolumnValue = cellStoreVector.get(i).toString(); 
                secondcolumnValue = cellStoreVector.get(i+1).toString();
 
                insertQuery(firstcolumnValue,secondcolumnValue);
 
 
 
 
            }
 
 
 
 
        } catch (IOException e) {
 
            e.printStackTrace();
 
        } finally {
 
            if (fis != null) {
 
                fis.close();
 
            }
 
        }
 
//      showExelData(sheetData);
 
    }
 
    private static void insertQuery(String firstcolumnvalue,String secondcolumnvalue) {
 
        System.out.println(firstcolumnvalue +  " "  +secondcolumnvalue);
 
 
    }
 
 
 
}